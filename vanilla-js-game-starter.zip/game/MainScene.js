import { Camera } from '../engine/graphics/Camera.js';
import { ParallaxLayer } from '../engine/graphics/ParallaxLayer.js';
import { CollisionSystem } from '../engine/collision/CollisionSystem.js';
import { TileMap } from '../engine/world/TileMap.js';
import { Player } from './entities/Player.js';
import { Enemy } from './entities/Enemy.js';
import { Pickup } from './entities/Pickup.js';
import { TiledLoader } from '../engine/assets/TiledLoader.js';

const MODE_CONFIG = {
  platformer: { gravity: 900, movement: 'platformer', primary: 'horiz', axes: {x:true,y:true} },
  runngun:    { gravity: 900, movement: 'platformer', primary: 'mouse', axes: {x:true,y:true} },
  shmup:      { gravity: 0,   movement: 'free',       primary: 'up',    axes: {x:true,y:true} },
  topdown:    { gravity: 0,   movement: 'free',       primary: 'mouse', axes: {x:true,y:true} }
};

export class MainScene {
  constructor(game, options = {}) {
    this.game = game; this.objects = []; this.collision = new CollisionSystem(64);
    this.camera = new Camera(game.canvas.width, game.canvas.height);
    this.parallax = [ new ParallaxLayer(this.game.loader.image('bg1'), 0.2), new ParallaxLayer(this.game.loader.image('bg2'), 0.4), new ParallaxLayer(this.game.loader.image('bg3'), 0.7) ];

    this.mode = (options.mode || 'platformer'); this.cfg = MODE_CONFIG[this.mode] || MODE_CONFIG.platformer;

    this._tiledUrl = options.tiledUrl || null; this._tiledJson = options.tiledJson || null; this.ready = false; this._init();
  }

  async _init() {
    let tilemap, spawns;
    if (this._tiledUrl) { const tl = new TiledLoader(this.game.loader); ({ tilemap, spawns } = await tl.loadFromURL(this._tiledUrl)); }
    else if (this._tiledJson) { const tl = new TiledLoader(this.game.loader); ({ tilemap, spawns } = await tl.loadFromObject(this._tiledJson)); }
    else {
      const T = 32, W = 50, H = 15; const tiles = Array.from({ length: H }, (_, y) => Array.from({ length: W }, (_, x) => (y === H - 1 || (y === H - 5 && x % 7 === 0)) ? 2 : -1));
      tilemap = new TileMap(tiles, T, this.game.loader.image('tiles'), new Set([2])); spawns = { player: { x: 100, y: 100 }, enemies: [], pickups: [] };
    }

    this.tilemap = tilemap; const worldW = this.tilemap.w * this.tilemap.tileSize; const worldH = this.tilemap.h * this.tilemap.tileSize;

    const playerSpawn = spawns.player || { x: 100, y: 100 };
    this.player = new Player(playerSpawn.x, playerSpawn.y, this.game.loader.image('player'), { movement: this.cfg.movement, gravity: this.cfg.gravity, primary: this.cfg.primary });
    this.objects.push(this.player);

    for (const e of (spawns.enemies || [])) this.objects.push(new Enemy(e.x, e.y, this.game.loader.image('enemy')));
    for (const p of (spawns.pickups || [])) this.objects.push(new Pickup(p.x, p.y, this.game.loader.image('pickup')));

    this.camera.follow(this.player.pos); this.camera.setBounds(0, 0, worldW, worldH); this.camera.setAxes(this.cfg.axes.x, this.cfg.axes.y);

    this.ready = true;
  }

  addObject(o) { this.objects.push(o); }

  update(dt) {
    if (!this.ready) return; const input = this.game.input;

    if (input.pressed('Digit1')) this.camera.setAxes(true, false);
    if (input.pressed('Digit2')) this.camera.setAxes(false, true);
    if (input.pressed('Digit3')) this.camera.setAxes(true, true);
    if (input.pressed('KeyC')) this.camera.deadzoneMode = this.camera.deadzoneMode === 'ratio' ? 'px' : 'ratio';
    if (input.pressed('KeyG')) this.camera.debugShowDeadzone = !this.camera.debugShowDeadzone;

    if (input.pressed('KeyO')) { if (this.camera.deadzoneMode === 'ratio') this.camera.deadzone.w = Math.max(0.05, this.camera.deadzone.w - 0.05); else this.camera.deadzonePx.w = Math.max(40, this.camera.deadzonePx.w - 20); }
    if (input.pressed('KeyP')) { if (this.camera.deadzoneMode === 'ratio') this.camera.deadzone.w = Math.min(0.9, this.camera.deadzone.w + 0.05); else this.camera.deadzonePx.w = Math.min(this.game.canvas.width, this.camera.deadzonePx.w + 20); }
    if (input.pressed('KeyK')) { if (this.camera.deadzoneMode === 'ratio') this.camera.deadzone.h = Math.max(0.05, this.camera.deadzone.h - 0.05); else this.camera.deadzonePx.h = Math.max(40, this.camera.deadzonePx.h - 20); }
    if (input.pressed('KeyL')) { if (this.camera.deadzoneMode === 'ratio') this.camera.deadzone.h = Math.min(0.9, this.camera.deadzone.h + 0.05); else this.camera.deadzonePx.h = Math.min(this.game.canvas.height, this.camera.deadzonePx.h + 20); }

    for (const o of this.objects) { if (!o.alive) continue; o.grounded = false; o.update(dt, this); }

    this.collision.staticSolids.length = 0;
    for (const o of this.objects) {
      if (!o.alive || !o.collider) continue; const around = this.tilemap.querySolidsAround(o.getAABB(), 1);
      for (const s of around) s.tag = s.tag || 'tile'; this.collision.staticSolids.push(...around);
    }

    this.collision.update(this.objects.filter(o => o.alive)); this.objects = this.objects.filter(o => o.alive);
    this.camera.update(dt); this.game.input.postUpdate();
  }

  render(ctx) {
    if (!this.ready) return;
    for (const layer of this.parallax) layer.render(ctx, this.camera, this.game.canvas.width, this.game.canvas.height);
    this.tilemap.render(ctx, this.camera);
    const visible = this.objects.slice().sort((a,b)=> a.z - b.z); for (const o of visible) o.render(ctx, this.camera);
    this.camera.renderDeadzoneOverlay(ctx);

    ctx.fillStyle = 'rgba(0,0,0,.5)'; ctx.fillRect(8, 8, 360, 70); ctx.fillStyle = '#fff'; ctx.font = '12px sans-serif';
    ctx.fillText(`Mode: ${this.mode}`, 16, 24);
    ctx.fillText(`Objets: ${this.objects.length}`, 16, 40);
    ctx.fillText(`Player: (${this.player.pos.x|0}, ${this.player.pos.y|0}) v=(${this.player.vel.x|0}, ${this.player.vel.y|0})`, 16, 56);
  }
}
