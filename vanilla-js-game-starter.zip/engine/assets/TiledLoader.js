import { TileMap } from '../world/TileMap.js';

export class TiledLoader {
  constructor(loader) { this.loader = loader; }

  async loadFromURL(url) {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Tiled JSON introuvable: ${url}`);
    const json = await res.json();
    return this._buildFromJSON(json);
  }

  async loadFromObject(json) { return this._buildFromJSON(json); }

  async _buildFromJSON(json) {
    if (json.orientation !== 'orthogonal') throw new Error('Seul le mode orthogonal Tiled est supporté.');
    const tileW = json.tilewidth, tileH = json.tileheight;

    const ts0 = json.tilesets[0];
    const firstGid = ts0.firstgid || 1;
    const tilesetImgKey = 'tiles';

    if (!this.loader.image(tilesetImgKey)) {
      if (ts0.image) {
        await this.loader.loadImage(tilesetImgKey, ts0.image);
      } else {
        throw new Error('Tileset image introuvable et clé "tiles" absente des assets.');
      }
    }

    const solidIndexes = new Set();
    if (Array.isArray(ts0.tiles)) {
      for (const t of ts0.tiles) {
        const props = (t.properties || []).reduce((acc,p)=> (acc[p.name]=p.value, acc), {});
        if (props.solid) solidIndexes.add(firstGid + t.id);
      }
    }

    const tileLayer = json.layers.find(l => l.type === 'tilelayer');
    if (!tileLayer) throw new Error('Aucune tilelayer dans le JSON Tiled.');
    const W = tileLayer.width, H = tileLayer.height;

    let data = tileLayer.data;
    if (typeof data === 'string') {
      // si base64, etc. (hors scope ici)
      throw new Error('Encodage de layer non supporté (attendu: CSV ou tableau).');
    }

    const tiles2D = [];
    for (let y = 0; y < H; y++) {
      tiles2D[y] = [];
      for (let x = 0; x < W; x++) {
        const gid = data[y * W + x] || 0;
        tiles2D[y][x] = gid === 0 ? -1 : gid;
      }
    }

    const tilemap = new TileMap(tiles2D, tileW, this.loader.image(tilesetImgKey), solidIndexes);

    const spawns = { player: null, enemies: [], pickups: [] };
    for (const layer of json.layers) {
      if (layer.type === 'objectgroup') {
        for (const o of layer.objects) {
          const type = (o.type || o.name || '').toLowerCase();
          const ox = Math.round(o.x), oy = Math.round(o.y - tileH);
          if (type === 'player' && !spawns.player) spawns.player = { x: ox, y: oy };
          else if (type === 'enemy') spawns.enemies.push({ x: ox, y: oy });
          else if (type === 'pickup') spawns.pickups.push({ x: ox, y: oy });
        }
      }
    }

    return { tilemap, spawns };
  }
}
