export class ParallaxLayer {
  constructor(image, factor = 0.5) { this.image=image; this.factor=factor; this.visible=true; this.yOffset=0; }
  render(ctx, camera, canvasW, canvasH) {
    if (!this.visible) return; const img=this.image;
    const parallaxX = camera.pos.x * this.factor; const parallaxY = camera.pos.y * this.factor;
    const startX = - (parallaxX % img.width); const startY = - ((parallaxY + this.yOffset) % img.height);
    for (let y = startY - img.height; y < canvasH + img.height; y += img.height) {
      for (let x = startX - img.width; x < canvasW + img.width; x += img.width) {
        ctx.drawImage(img, x|0, y|0);
      }
    }
  }
}
