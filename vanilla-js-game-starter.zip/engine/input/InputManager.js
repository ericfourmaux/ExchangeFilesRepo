export class InputManager {
  constructor(canvas) {
    this.keysDown = new Set();
    this.keysPressed = new Set();
    this.keysReleased = new Set();

    this.mouse = { x: 0, y: 0, down: false, pressed: false, released: false, button: 0 };

    window.addEventListener('keydown', (e) => {
      if (!this.keysDown.has(e.code)) this.keysPressed.add(e.code);
      this.keysDown.add(e.code);
    });
    window.addEventListener('keyup', (e) => {
      this.keysDown.delete(e.code);
      this.keysReleased.add(e.code);
    });

    const updateMousePos = (e) => {
      const rect = canvas.getBoundingClientRect();
      this.mouse.x = ((e.clientX - rect.left) / rect.width) * canvas.width;
      this.mouse.y = ((e.clientY - rect.top) / rect.height) * canvas.height;
    };

    canvas.addEventListener('mousemove', updateMousePos);
    canvas.addEventListener('mousedown', (e) => {
      updateMousePos(e);
      this.mouse.button = e.button;
      if (!this.mouse.down) this.mouse.pressed = true;
      this.mouse.down = true;
    });
    window.addEventListener('mouseup', (e) => {
      this.mouse.down = false;
      this.mouse.released = true;
    });

    // Autoriser clic droit pour jeux
    canvas.addEventListener('contextmenu', (e) => e.preventDefault());
  }

  postUpdate() {
    this.keysPressed.clear();
    this.keysReleased.clear();
    this.mouse.pressed = false;
    this.mouse.released = false;
  }

  isDown(code) { return this.keysDown.has(code); }
  pressed(code) { return this.keysPressed.has(code); }
  released(code) { return this.keysReleased.has(code); }
}
