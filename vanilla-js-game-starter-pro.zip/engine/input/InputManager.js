
export class InputManager {
  constructor(canvas) {
    this.keysDown = new Set(); this.keysPressed = new Set(); this.keysReleased = new Set();
    this.mouse = { x:0, y:0, down:false, pressed:false, released:false, button:0 };

    window.addEventListener('keydown',(e)=>{ if(!this.keysDown.has(e.code)) this.keysPressed.add(e.code); this.keysDown.add(e.code); });
    window.addEventListener('keyup',(e)=>{ this.keysDown.delete(e.code); this.keysReleased.add(e.code); });

    const upd = (e)=>{ const r=canvas.getBoundingClientRect(); this.mouse.x=((e.clientX-r.left)/r.width)*canvas.width; this.mouse.y=((e.clientY-r.top)/r.height)*canvas.height; };
    canvas.addEventListener('mousemove', upd);
    canvas.addEventListener('mousedown', (e)=>{ upd(e); this.mouse.button=e.button; if(!this.mouse.down) this.mouse.pressed=true; this.mouse.down=true; });
    window.addEventListener('mouseup', (e)=>{ this.mouse.down=false; this.mouse.released=true; });
    canvas.addEventListener('contextmenu', (e)=> e.preventDefault());
  }
  postUpdate(){ this.keysPressed.clear(); this.keysReleased.clear(); this.mouse.pressed=false; this.mouse.released=false; }
  isDown(c){ return this.keysDown.has(c); } pressed(c){ return this.keysPressed.has(c);} released(c){ return this.keysReleased.has(c);} 
}
