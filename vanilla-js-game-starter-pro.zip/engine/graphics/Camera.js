
export class Camera {
  constructor(viewW, viewH){ this.pos={x:0,y:0}; this.viewW=viewW; this.viewH=viewH; this.worldBounds={x:0,y:0,w:Infinity,h:Infinity}; this.deadzoneMode='ratio'; this.deadzone={x:0.4,y:0.4,w:0.2,h:0.2}; this.deadzonePx={x:200,y:120,w:200,h:160}; this.target=null; this.lerp=0.15; this.axes={x:true,y:true}; this.debugShowDeadzone=false; }
  follow(t){ this.target=t; } setBounds(x,y,w,h){ this.worldBounds={x,y,w,h}; } setAxes(h=true,v=true){ this.axes.x=h; this.axes.y=v; }
  setDeadzoneRatio(x,y,w,h){ this.deadzoneMode='ratio'; this.deadzone={x,y,w,h}; } setDeadzonePx(x,y,w,h){ this.deadzoneMode='px'; this.deadzonePx={x,y,w,h}; }
  _dz(){ if(this.deadzoneMode==='ratio'){ return { x:this.viewW*this.deadzone.x, y:this.viewH*this.deadzone.y, w:this.viewW*this.deadzone.w, h:this.viewH*this.deadzone.h }; } return { ...this.deadzonePx }; }
  update(dt){ if(!this.target) return; const dz=this._dz(); const tx=this.target.x-this.pos.x; const ty=this.target.y-this.pos.y; let dx=this.pos.x, dy=this.pos.y; if(this.axes.x){ if(tx<dz.x) dx=this.target.x-dz.x; else if(tx>dz.x+dz.w) dx=this.target.x-(dz.x+dz.w);} if(this.axes.y){ if(ty<dz.y) dy=this.target.y-dz.y; else if(ty>dz.y+dz.h) dy=this.target.y-(dz.y+dz.h);} this.pos.x+=(dx-this.pos.x)*this.lerp; this.pos.y+=(dy-this.pos.y)*this.lerp; this.pos.x=Math.max(this.worldBounds.x, Math.min(this.pos.x, this.worldBounds.x+this.worldBounds.w-this.viewW)); this.pos.y=Math.max(this.worldBounds.y, Math.min(this.pos.y, this.worldBounds.y+this.worldBounds.h-this.viewH)); }
  worldToScreen(x,y){ return { x:x-this.pos.x, y:y-this.pos.y }; }
  renderDeadzoneOverlay(ctx){ if(!this.debugShowDeadzone) return; const dz=this._dz(); ctx.save(); ctx.strokeStyle='rgba(255,255,0,0.9)'; ctx.setLineDash([6,4]); ctx.strokeRect(dz.x|0,dz.y|0,dz.w|0,dz.h|0); ctx.restore(); }
}
