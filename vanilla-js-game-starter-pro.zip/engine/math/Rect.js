
export class Rect { constructor(x=0,y=0,w=0,h=0){ this.x=x; this.y=y; this.w=w; this.h=h; } get left(){ return this.x;} get right(){ return this.x+this.w;} get top(){ return this.y;} get bottom(){ return this.y+this.h;} intersects(o){ return !(this.right<=o.left||this.left>=o.right||this.bottom<=o.top||this.top>=o.bottom); } }
