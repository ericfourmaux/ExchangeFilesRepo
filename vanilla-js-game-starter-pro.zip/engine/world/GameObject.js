
import { AABBCollider } from '../collision/Colliders.js';
let _idSeq=1;
export class GameObject { constructor(x=0,y=0,w=16,h=16){ this._id=_idSeq++; this.pos={x,y}; this.vel={x:0,y:0}; this.size={w,h}; this.z=0; this.sprite=null; this.animation=null; this.collider=new AABBCollider(w,h).attach(this); this.gravity=900; this.friction=0.85; this.grounded=false; this.flipX=false; this.tag=''; this.alive=true; }
  getAABB(){ return { x:this.pos.x, y:this.pos.y, w:this.size.w, h:this.size.h }; }
  update(dt,scene){ if(!this.grounded) this.vel.y+=this.gravity*dt; this.pos.x+=this.vel.x*dt; this.pos.y+=this.vel.y*dt; this.animation?.update(dt); }
  render(ctx,camera){ const s=camera.worldToScreen(this.pos.x,this.pos.y); if(this.sprite){ if(this.animation){ const f=this.animation.currentFrame(); if(f&&f.w!==undefined) this.sprite.drawFrameRect(ctx,s.x,s.y,f,{flipX:this.flipX}); else this.sprite.draw(ctx,s.x,s.y,{frame:f??0,flipX:this.flipX}); } else { this.sprite.draw(ctx,s.x,s.y,{frame:0,flipX:this.flipX}); } } else { ctx.fillStyle='#e74c3c'; ctx.fillRect(s.x|0,s.y|0,this.size.w,this.size.h);} }
  onCollision(o,info){} onTrigger(o){}
}
