
export class Pool {
  constructor(factory){ this.factory=factory; this.items=[]; }
  acquire(){ return this.items.pop() || this.factory(); }
  release(obj){ this.items.push(obj); }
  size(){ return this.items.length; }
}
