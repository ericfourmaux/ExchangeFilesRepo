
import { Camera } from '../engine/graphics/Camera.js';
import { ParallaxLayer } from '../engine/graphics/ParallaxLayer.js';
import { CollisionSystem } from '../engine/collision/CollisionSystem.js';
import { TileMap } from '../engine/world/TileMap.js';
import { Player } from './entities/Player.js';
import { Enemy } from './entities/Enemy.js';
import { Pickup } from './entities/Pickup.js';
import { TiledLoader } from '../engine/assets/TiledLoader.js';
import { Pool } from '../engine/utils/Pool.js';
import { Projectile } from './entities/Projectile.js';
import { HUD } from './ui/HUD.js';

const MODE_CONFIG = {
  platformer: { gravity: 900, movement: 'platformer', primary: 'horiz', axes: {x:true,y:true} },
  runngun:    { gravity: 900, movement: 'platformer', primary: 'mouse', axes: {x:true,y:true} },
  shmup:      { gravity: 0,   movement: 'free',       primary: 'up',    axes: {x:true,y:true}, scrollY: -60 },
  topdown:    { gravity: 0,   movement: 'free',       primary: 'mouse', axes: {x:true,y:true} }
};

export class MainScene {
  constructor(game, options = {}){
    this.game = game; this.objects = []; this.collision = new CollisionSystem(64); this.camera = new Camera(game.canvas.width, game.canvas.height);
    this.parallax = [ new ParallaxLayer(this.game.loader.image('bg1'),0.2), new ParallaxLayer(this.game.loader.image('bg2'),0.4), new ParallaxLayer(this.game.loader.image('bg3'),0.7) ];
    this.mode = (options.mode || 'platformer'); this.cfg = MODE_CONFIG[this.mode] || MODE_CONFIG.platformer;
    this._tiledUrl = options.tiledUrl || 'assets/level1.json'; this._tiledJson = options.tiledJson || null; this.ready=false;
    this.projectilePool = new Pool(()=> new Projectile());
    this.hud = new HUD(this);
    this.score = 0; this.lives = 3;
    this._waveTimer = 0; this._waveInterval = 2.2; // shmup
    this._init();
  }

  async _init(){
    let tilemap, spawns;
    if(this._tiledUrl){ const tl=new TiledLoader(this.game.loader); ({tilemap, spawns} = await tl.loadFromURL(this._tiledUrl)); }
    else if(this._tiledJson){ const tl=new TiledLoader(this.game.loader); ({tilemap, spawns} = await tl.loadFromObject(this._tiledJson)); }
    else { const T=32,W=50,H=15; const tiles=Array.from({length:H},(_,y)=>Array.from({length:W},(_,x)=>(y===H-1||(y===H-5&&x%7===0))?2:-1)); tilemap=new TileMap(tiles,T,this.game.loader.image('tiles'),new Set([2])); spawns={ player:{x:100,y:100}, enemies:[], pickups:[] }; }

    this.tilemap = tilemap; const worldW=this.tilemap.w*this.tilemap.tileSize; const worldH=this.tilemap.h*this.tilemap.tileSize;
    const pSpawn = spawns.player || { x:100, y:100 };
    this.player = new Player(pSpawn.x, pSpawn.y, this.game.loader.image('player'), { movement:this.cfg.movement, gravity:this.cfg.gravity, primary:this.cfg.primary });
    this.player.addScore = (v)=>{ this.score+=v; };
    this.objects.push(this.player);

    for(const e of (spawns.enemies||[])) this.objects.push(new Enemy(e.x,e.y,this.game.loader.image('enemy')));
    for(const p of (spawns.pickups||[])) this.objects.push(new Pickup(p.x,p.y,this.game.loader.image('pickup')));

    this.camera.follow(this.player.pos); this.camera.setBounds(0,0,worldW,worldH); this.camera.setAxes(this.cfg.axes.x,this.cfg.axes.y);
    this.ready=true;
  }

  addObject(o){ this.objects.push(o); }

  // --- Pool-based projectile spawner ---
  spawnBullet(x,y,vx,vy,opts={}){ const obj=this.projectilePool.acquire(); obj.reset(x,y,vx,vy,opts); this.addObject(obj); }

  // Secondary (burst) handled here so it can use pool easily
  startBurst(dir){ this._burst={ pending:3, timer:0, interval:0.05, dir:{x:dir.x,y:dir.y}, speed:520 }; }
  _processBurst(dt){ if(!this._burst || this._burst.pending<=0) return; this._burst.timer -= dt; if(this._burst.timer<=0){ const s=Math.hypot(this._burst.dir.x,this._burst.dir.y)||1; const nx=this._burst.dir.x/s, ny=this._burst.dir.y/s; const spread=(Math.random()-0.5)*0.12; const rx=nx*Math.cos(spread)-ny*Math.sin(spread), ry=nx*Math.sin(spread)+ny*Math.cos(spread); const mzx=this.player.pos.x+this.player.size.w/2, mzy=this.player.pos.y+this.player.size.h/2; this.spawnBullet(mzx,mzy,rx*this._burst.speed,ry*this._burst.speed,{color:'#ffa94d',life:0.9,radius:3}); this._burst.pending--; this._burst.timer=this._burst.interval; this.game.sounds.beep({frequency:940,duration:0.04,type:'triangle',volume:0.1}); } }

  _shmupAutoScroll(dt){ if(this.mode!=='shmup') return; const spd = this.cfg.scrollY || -60; this.camera.pos.y += spd * dt; // vers le haut négatif
    // clamp caméra à bounds
    this.camera.pos.y = Math.max(this.camera.worldBounds.y, Math.min(this.camera.pos.y, this.camera.worldBounds.y + this.camera.worldBounds.h - this.camera.viewH));
    // Contrainte joueur dans l'écran
    const pxMin=this.camera.pos.x+8, pyMin=this.camera.pos.y+8; const pxMax=this.camera.pos.x+this.camera.viewW-8-this.player.size.w; const pyMax=this.camera.pos.y+this.camera.viewH-8-this.player.size.h; this.player.pos.x=Math.max(pxMin,Math.min(this.player.pos.x,pxMax)); this.player.pos.y=Math.max(pyMin,Math.min(this.player.pos.y,pyMax));
    // Vagues d'ennemis
    this._waveTimer-=dt; if(this._waveTimer<=0){ this._spawnWave(); this._waveTimer=this._waveInterval; }
  }

  _spawnWave(){ const y=this.camera.pos.y-40; const w=this.game.canvas.width; const tiles= this.tilemap.tileSize; const x0=this.camera.pos.x+40; const x1=this.camera.pos.x+w-40; const step=(x1-x0)/4; for(let i=0;i<3;i++){ const ex=x0+step*(i+1); this.objects.push(new Enemy(ex,y,this.game.loader.image('enemy'))); }
  }

  update(dt){ if(!this.ready) return; const input=this.game.input;
    if(input.pressed('Digit1')) this.camera.setAxes(true,false); if(input.pressed('Digit2')) this.camera.setAxes(false,true); if(input.pressed('Digit3')) this.camera.setAxes(true,true); if(input.pressed('KeyC')) this.camera.deadzoneMode=this.camera.deadzoneMode==='ratio'?'px':'ratio'; if(input.pressed('KeyG')) this.camera.debugShowDeadzone=!this.camera.debugShowDeadzone; if(input.pressed('KeyO')){ if(this.camera.deadzoneMode==='ratio') this.camera.deadzone.w=Math.max(0.05,this.camera.deadzone.w-0.05); else this.camera.deadzonePx.w=Math.max(40,this.camera.deadzonePx.w-20); } if(input.pressed('KeyP')){ if(this.camera.deadzoneMode==='ratio') this.camera.deadzone.w=Math.min(0.9,this.camera.deadzone.w+0.05); else this.camera.deadzonePx.w=Math.min(this.game.canvas.width,this.camera.deadzonePx.w+20); } if(input.pressed('KeyK')){ if(this.camera.deadzoneMode==='ratio') this.camera.deadzone.h=Math.max(0.05,this.camera.deadzone.h-0.05); else this.camera.deadzonePx.h=Math.max(40,this.camera.deadzonePx.h-20); } if(input.pressed('KeyL')){ if(this.camera.deadzoneMode==='ratio') this.camera.deadzone.h=Math.min(0.9,this.camera.deadzone.h+0.05); else this.camera.deadzonePx.h=Math.min(this.game.canvas.height,this.camera.deadzonePx.h+20); }

    // Updates
    for(const o of this.objects){ if(!o.alive) continue; o.grounded=false; if(o._inv){ o._inv=Math.max(0,o._inv-dt);} o.update(dt,this); }

    // Collisions with tiles
    this.collision.staticSolids.length=0; for(const o of this.objects){ if(!o.alive||!o.collider) continue; const around=this.tilemap.querySolidsAround(o.getAABB(),1); for(const s of around) s.tag=s.tag||'tile'; this.collision.staticSolids.push(...around); }
    this.collision.update(this.objects.filter(o=>o.alive));

    // Pool cleanup & deaths
    this.objects = this.objects.filter(o=>{ if(o.alive) return true; if(o._pooled){ this.projectilePool.release(o); return false; } if(o.tag==='player'){ this._onPlayerDeath(); return false; } return false; });

    // Camera & mode-specific behaviors
    if(this.mode==='shmup'){ this._shmupAutoScroll(dt); } else { this.camera.update(dt); }

    // Burst firing
    this._processBurst(dt);

    // End input
    this.game.input.postUpdate();
  }

  _onPlayerDeath(){ this.lives--; if(this.lives>=0){ // respawn simple
      const spawnY = Math.max(this.camera.pos.y+40, 80);
      this.player.alive=true; this.player.hp=3; this.player.pos.x=this.camera.pos.x+this.game.canvas.width/2-12; this.player.pos.y=spawnY; this.objects.push(this.player); this.game.sounds.beep({frequency:300,duration:0.2,type:'sawtooth',volume:0.1}); }
    else { this.game.sounds.beep({frequency:160,duration:0.4,type:'square',volume:0.15}); /* TODO: écran Game Over */ }
  }

  render(ctx){ if(!this.ready) return; for(const layer of this.parallax) layer.render(ctx,this.camera,this.game.canvas.width,this.game.canvas.height); this.tilemap.render(ctx,this.camera); const vis=this.objects.slice().sort((a,b)=>a.z-b.z); for(const o of vis) o.render(ctx,this.camera); this.camera.renderDeadzoneOverlay(ctx); this.hud.render(ctx); }
}
