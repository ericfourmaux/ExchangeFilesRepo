
import { GameObject } from '../../engine/world/GameObject.js';
import { Sprite } from '../../engine/graphics/Sprite.js';
import { AABBCollider } from '../../engine/collision/Colliders.js';

export class Enemy extends GameObject {
  constructor(x,y,img){ super(x,y,24,24); this.tag='enemy'; this.sprite=new Sprite(img,24,24); this.collider=new AABBCollider(22,22).attach(this); this.collider.offset.set?.(1,1); this.patrol={ left:x-60, right:x+60, speed:60 }; this.vel.x=this.patrol.speed; this.hp=3; this.state='patrol'; this.sight=180; this.attackRange=28; this.fireCooldown=1.0; this._cd=0; }
  hurt(d=1){ this.hp-=d; if(this.hp<=0){ this.alive=false; } }
  distTo(p){ const dx=(p.x+12)-(this.pos.x+12), dy=(p.y+12)-(this.pos.y+12); return Math.hypot(dx,dy); }
  update(dt,scene){ const player=scene.player; if(!player){ super.update(dt,scene); return; }
    const d=this.distTo(player.pos); this._cd=Math.max(0,this._cd-dt);
    // FSM
    if(this.state==='patrol'){ if(this.pos.x<this.patrol.left) this.vel.x=Math.abs(this.patrol.speed); if(this.pos.x>this.patrol.right) this.vel.x=-Math.abs(this.patrol.speed); if(d<this.sight) this.state='chase'; }
    else if(this.state==='chase'){ this.vel.x = (player.pos.x<this.pos.x? -1:1)*Math.abs(this.patrol.speed); if(d<this.attackRange) this.state='attack'; if(d>this.sight*1.2) this.state='patrol'; }
    else if(this.state==='attack'){ // simple dash/strike
      if(d>this.attackRange*1.5) this.state='chase';
      // Optionnel: tirs dans modes free
      if((scene.mode==='shmup'||scene.mode==='topdown') && this._cd<=0){ const dirX=(player.pos.x-this.pos.x); const dirY=(player.pos.y-this.pos.y); const len=Math.hypot(dirX,dirY)||1; const nx=dirX/len, ny=dirY/len; scene.spawnBullet(this.pos.x+12,this.pos.y+12,nx*220,ny*220,{color:'#ff6b6b', life:2, radius:3, damage:1}); this._cd=1.2; }
      // petit knock vers joueur en modes plateformes
      if(scene.cfg.movement==='platformer') this.vel.x=(player.pos.x<this.pos.x?-1:1)*120;
    }
    this.flipX=this.vel.x<0; super.update(dt,scene); }
}
