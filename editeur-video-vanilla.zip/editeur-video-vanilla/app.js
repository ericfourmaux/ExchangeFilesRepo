// Éditeur Vidéo en Vanilla JS
// - Cible: vidéos <= 15min, Chrome/Firefox
// - UI: marqueurs, A–B, boucle, Piste 2 (collages)
// - Export MP4: par défaut via FFmpeg.wasm (stream copy si possible, sinon H.264 ré-encode). Option expérimental WebCodecs+mp4-muxer
// - Édition des métadonnées MP4: titre, artiste, album, année, commentaire (stream copy)

(function(){
  'use strict';

  // ====== Éléments ======
  const fileInput = document.getElementById('fileInput');
  const videoEl = document.getElementById('video');
  const timeline = document.getElementById('timeline');
  const tctx = timeline.getContext('2d');
  const currentTimeEl = document.getElementById('currentTime');
  const totalTimeEl = document.getElementById('totalTime');
  const markerListEl = document.getElementById('markerList');
  const markerAEl = document.getElementById('markerA');
  const markerBEl = document.getElementById('markerB');
  const loopABEl = document.getElementById('loopAB');
  const fileInfoEl = document.getElementById('fileInfo');
  const logEl = document.getElementById('log');
  const statusEl = document.getElementById('status');
  const track2ListEl = document.getElementById('track2List');
  const smartCopyEl = document.getElementById('smartCopy');
  const forceReencodeEl = document.getElementById('forceReencode');

  const metaForm = document.getElementById('metaForm');

  // ====== État ======
  let file = null; // File
  let fileU8 = null; // Uint8Array
  let duration = 0;

  let markers = []; // {id, time}
  let selectedMarkerId = null;
  let A = null, B = null; // secondes

  let playingAB = false;

  let clipboard = null; // {start, end}
  let track2 = []; // [{start,end}]

  // FFmpeg
  let ffmpeg = null;
  let ffmpegLoaded = false;

  // ====== Utilitaires ======
  const fmtTime = (sec)=>{
    if (!isFinite(sec)) return '00:00.000';
    const s = Math.max(0, sec);
    const m = Math.floor(s/60);
    const r = s - m*60;
    const rInt = Math.floor(r);
    const ms = Math.round((r - rInt)*1000);
    const pad=(n,w=2)=> String(n).padStart(w,'0');
    return `${pad(m)}:${pad(rInt)}.${pad(ms,3)}`;
  };
  const parseTime = (txt)=>{
    if (!txt) return null;
    const m = txt.match(/^(?:(\d+):)?(\d+)(?:\.(\d{1,3}))?$/);
    if (!m) return null;
    const min = parseInt(m[1]||'0',10);
    const sec = parseInt(m[2]||'0',10);
    const ms = parseInt((m[3]||'0').padEnd(3,'0'),10);
    return min*60 + sec + ms/1000;
  };
  function log(msg){ logEl.textContent += `\n${msg}`; logEl.scrollTop = logEl.scrollHeight; }
  function setStatus(msg){ statusEl.textContent = msg || ''; }
  function enable(sel){ document.querySelectorAll(`[data-action="${sel}"]`).forEach(b=>b.disabled=false); }
  function disable(sel){ document.querySelectorAll(`[data-action="${sel}"]`).forEach(b=>b.disabled=true); }
  function selectionValid(){ return duration>0 && A!=null && B!=null && Math.max(A,B) > Math.min(A,B); }
  function updateSelButtons(){ const v=selectionValid();
    document.querySelectorAll('[data-action="copy"],[data-action="export-segment"],[data-action="play-AB"]').forEach(b=>b.disabled=!v);
  }

  // ====== Menu ======
  document.querySelectorAll('.menu-btn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const name = btn.dataset.menu;
      document.querySelectorAll('.menu-dropdown').forEach(dd=>{
        dd.classList.toggle('open', dd.dataset.dropdown===name && !dd.classList.contains('open'));
        if (dd.dataset.dropdown!==name) dd.classList.remove('open');
      });
    });
  });
  document.addEventListener('click',(e)=>{
    if (!e.target.closest('.menu-group')){
      document.querySelectorAll('.menu-dropdown').forEach(dd=>dd.classList.remove('open'));
    }
  });

  // ====== Fichier ======
  document.querySelectorAll('[data-action="open-file"]').forEach(b=>b.addEventListener('click', ()=>fileInput.click()));
  fileInput.addEventListener('change', async (e)=>{
    file = e.target.files?.[0] || null;
    if (!file) return;
    if (file.size > 1024*1024*1024) { alert('Fichier volumineux : l\'export peut être lent.'); }
    const url = URL.createObjectURL(file);
    videoEl.src = url;
    fileU8 = new Uint8Array(await file.arrayBuffer());
    fileInfoEl.textContent = `${file.name} • ${(file.size/1024/1024).toFixed(2)} Mo`;
    enable('save-metadata');
    setStatus('Fichier chargé.');
  });

  videoEl.addEventListener('loadedmetadata', ()=>{
    duration = videoEl.duration || 0;
    totalTimeEl.textContent = fmtTime(duration);
    drawTimeline();
    enable('play');
  });
  videoEl.addEventListener('timeupdate', ()=>{
    currentTimeEl.textContent = fmtTime(videoEl.currentTime);
    if (playingAB && selectionValid()){
      const s = Math.min(A,B), e = Math.max(A,B);
      if (videoEl.currentTime>=e){
        if (loopABEl.checked){ videoEl.currentTime = s; videoEl.play(); }
        else { playingAB=false; }
      }
    }
    drawTimeline();
  });

  // ====== Timeline (clic = position, Alt = A, Shift = B) ======
  timeline.addEventListener('mousedown', (e)=>{
    if (!duration) return;
    const rect = timeline.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const t = x / timeline.width * duration;
    if (e.altKey){ A = t; markerAEl.value = fmtTime(A); updateSelButtons(); }
    else if (e.shiftKey){ B = t; markerBEl.value = fmtTime(B); updateSelButtons(); }
    else { videoEl.currentTime = t; }
    drawTimeline();
  });

  function drawTimeline(){
    const W = timeline.width, H = timeline.height;
    tctx.clearRect(0,0,W,H);
    tctx.fillStyle = '#0b1220';
    tctx.fillRect(0,0,W,H);
    // grille simple (toutes les 10s)
    const every = Math.max(1, Math.round(duration/12));
    tctx.strokeStyle='rgba(255,255,255,.08)';
    tctx.beginPath();
    for(let t=0;t<duration;t+=every){ const x = t/duration*W; tctx.moveTo(x,0); tctx.lineTo(x,H); }
    tctx.stroke();
    // sélection A-B
    if (selectionValid()){
      const s = Math.min(A,B), e = Math.max(A,B);
      const x1 = s/duration*W, x2 = e/duration*W;
      tctx.fillStyle = 'rgba(99,102,241,.25)';
      tctx.fillRect(x1,0,x2-x1,H);
    }
    // marqueurs
    markers.sort((a,b)=>a.time-b.time);
    markers.forEach(m=>{
      const x = m.time/duration*W;
      tctx.strokeStyle = m.id===selectedMarkerId? '#f97316' : '#34d399';
      tctx.beginPath(); tctx.moveTo(x,0); tctx.lineTo(x,H); tctx.stroke();
    });
    // playhead
    const xCur = (videoEl.currentTime||0)/duration*W;
    tctx.strokeStyle = '#eab308'; tctx.beginPath(); tctx.moveTo(xCur,0); tctx.lineTo(xCur,H); tctx.stroke();
  }

  function renderMarkerList(){
    markerListEl.innerHTML='';
    markers.forEach(m=>{
      const li = document.createElement('li');
      const left = document.createElement('span'); left.textContent = fmtTime(m.time);
      const right = document.createElement('span');
      const go = document.createElement('button'); go.textContent='Aller'; go.addEventListener('click',()=>videoEl.currentTime=m.time);
      const sel = document.createElement('button'); sel.textContent='Sélectionner'; sel.addEventListener('click',()=>{ selectedMarkerId=m.id; renderMarkerList(); drawTimeline(); enable('delete-selected-marker'); });
      li.append(left); right.append(sel,go); li.append(right);
      if (m.id===selectedMarkerId) li.style.background='#fff7ed';
      markerListEl.append(li);
    });
    if (!selectedMarkerId){ disable('delete-selected-marker'); }
  }

  // ====== Actions UI ======
  document.querySelectorAll('[data-action="play"]').forEach(b=>b.addEventListener('click',()=>{ videoEl.play(); document.querySelector('[data-action="pause"]').disabled=false; document.querySelector('[data-action="stop"]').disabled=false; }));
  document.querySelectorAll('[data-action="pause"]').forEach(b=>b.addEventListener('click',()=>{ videoEl.pause(); }));
  document.querySelectorAll('[data-action="stop"]').forEach(b=>b.addEventListener('click',()=>{ videoEl.pause(); videoEl.currentTime=0; }));
  document.querySelectorAll('[data-action="back-1s"]').forEach(b=>b.addEventListener('click',()=>{ videoEl.currentTime=Math.max(0, (videoEl.currentTime||0)-1); }));
  document.querySelectorAll('[data-action="play-AB"]').forEach(b=>b.addEventListener('click',()=>{
    if (!selectionValid()) return; const s=Math.min(A,B); videoEl.currentTime=s; playingAB=true; videoEl.play();
  }));
  document.querySelectorAll('[data-action="add-marker"]').forEach(b=>b.addEventListener('click',()=>{ const id=Math.random().toString(36).slice(2,9); markers.push({id,time:videoEl.currentTime||0}); renderMarkerList(); drawTimeline(); }));
  document.querySelectorAll('[data-action="delete-selected-marker"]').forEach(b=>b.addEventListener('click',()=>{ if(!selectedMarkerId) return; markers=markers.filter(m=>m.id!==selectedMarkerId); selectedMarkerId=null; renderMarkerList(); drawTimeline(); }));
  document.querySelectorAll('[data-action="set-A"]').forEach(b=>b.addEventListener('click',()=>{ A=videoEl.currentTime||0; markerAEl.value=fmtTime(A); updateSelButtons(); drawTimeline(); }));
  document.querySelectorAll('[data-action="set-B"]').forEach(b=>b.addEventListener('click',()=>{ B=videoEl.currentTime||0; markerBEl.value=fmtTime(B); updateSelButtons(); drawTimeline(); }));
  document.querySelectorAll('[data-action="clear-AB"]').forEach(b=>b.addEventListener('click',()=>{ A=B=null; markerAEl.value=''; markerBEl.value=''; updateSelButtons(); drawTimeline(); }));
  document.querySelectorAll('[data-action="apply-AB"]').forEach(b=>b.addEventListener('click',()=>{ const a=parseTime(markerAEl.value), b2=parseTime(markerBEl.value); if(a!=null)A=a; if(b2!=null)B=b2; updateSelButtons(); drawTimeline(); }));

  document.querySelectorAll('[data-action="copy"]').forEach(b=>b.addEventListener('click',()=>{
    if (!selectionValid()) return; clipboard={start:Math.min(A,B), end:Math.max(A,B)}; enable('paste-to-track2');
  }));
  document.querySelectorAll('[data-action="paste-to-track2"]').forEach(b=>b.addEventListener('click',()=>{
    if (!clipboard) return; track2.push({...clipboard}); renderTrack2(); enable('export-track2'); enable('clear-track2');
  }));
  document.querySelectorAll('[data-action="clear-track2"]').forEach(b=>b.addEventListener('click',()=>{ track2=[]; renderTrack2(); }));
  document.querySelectorAll('[data-action="play-track2"]').forEach(b=>b.addEventListener('click',()=>{ if(track2.length===0) return; // simple: lire A du premier segment
    videoEl.currentTime = track2[0].start; videoEl.play();
  }));

  function renderTrack2(){
    track2ListEl.innerHTML='';
    if (track2.length===0){ track2ListEl.innerHTML='<div class="small">Piste 2 vide. Utilisez « Coller ».</div>'; return; }
    track2.forEach((seg,i)=>{
      const div=document.createElement('div'); div.className='track2-item';
      const left=document.createElement('div'); left.textContent=`#${i+1}  ${fmtTime(seg.start)}–${fmtTime(seg.end)}  (${fmtTime(seg.end-seg.start)})`;
      const right=document.createElement('div');
      const up=document.createElement('button'); up.textContent='↑'; up.onclick=()=>{ if(i>0){ const t=track2[i-1]; track2[i-1]=track2[i]; track2[i]=t; renderTrack2(); } };
      const down=document.createElement('button'); down.textContent='↓'; down.onclick=()=>{ if(i<track2.length-1){ const t=track2[i+1]; track2[i+1]=track2[i]; track2[i]=t; renderTrack2(); } };
      const del=document.createElement('button'); del.textContent='Suppr'; del.onclick=()=>{ track2.splice(i,1); renderTrack2(); };
      right.append(up,down,del); div.append(left,right); track2ListEl.append(div);
    });
    enable('play-track2'); enable('export-track2');
  }

  // ====== Métadonnées ======
  document.querySelectorAll('[data-action="save-metadata"]').forEach(b=>b.addEventListener('click', async ()=>{
    if (!file || !fileU8) return; await ensureFFmpeg();
    setStatus('Écriture des métadonnées…');
    const fields = Object.fromEntries(new FormData(metaForm).entries());
    const inName = 'input.mp4'; const outName = 'output_meta.mp4';
    await ffmpeg.FS('writeFile', inName, fileU8);
    const args = ['-i', inName, '-map', '0', '-c', 'copy'];
    if (fields.title) args.push('-metadata','title='+fields.title);
    if (fields.artist) args.push('-metadata','artist='+fields.artist);
    if (fields.album) args.push('-metadata','album='+fields.album);
    if (fields.year) args.push('-metadata','date='+fields.year);
    if (fields.comment) args.push('-metadata','comment='+fields.comment);
    args.push(outName);
    await runFFmpeg(args);
    downloadFromFS(outName, safeName(fields.title||file.name.replace(/\.mp4$/i,''))+'_meta.mp4');
    setStatus('Métadonnées écrites.');
  }));

  // ====== Export segment ======
  document.querySelectorAll('[data-action="export-segment"]').forEach(b=>b.addEventListener('click', async ()=>{
    if (!selectionValid() || !fileU8) return; await ensureFFmpeg();
    const s = Math.min(A,B), e = Math.max(A,B);
    const inName = 'input.mp4'; const outName = 'segment.mp4';
    await ffmpeg.FS('writeFile', inName, fileU8);
    let args;
    if (forceReencodeEl.checked){
      args = ['-ss', s.toFixed(3), '-to', e.toFixed(3), '-i', inName, '-c:v', 'libx264', '-preset','veryfast', '-crf','23', '-c:a','copy', outName];
    } else if (smartCopyEl.checked){
      // Fast trim (copy). Attention: précis sur keyframes.
      args = ['-ss', s.toFixed(3), '-to', e.toFixed(3), '-i', inName, '-c', 'copy', outName];
    } else {
      args = ['-ss', s.toFixed(3), '-to', e.toFixed(3), '-i', inName, '-c:v', 'libx264', '-preset','veryfast', '-crf','23', '-c:a','copy', outName];
    }
    setStatus('Export du segment…');
    await runFFmpeg(args);
    downloadFromFS(outName, `segment_${fmtTime(s).replace(/[:\.]/g,'-')}_${fmtTime(e).replace(/[:\.]/g,'-')}.mp4`);
    setStatus('Segment exporté.');
  }));

  // ====== Export Piste 2 ======
  document.querySelectorAll('[data-action="export-track2"]').forEach(b=>b.addEventListener('click', async ()=>{
    if (track2.length===0 || !fileU8) return; await ensureFFmpeg();
    setStatus('Préparation des segments…');
    await ffmpeg.FS('writeFile', 'input.mp4', fileU8);

    const parts = [];
    // On génère des sous-fichiers compatibles puis concat
    for (let i=0;i<track2.length;i++){
      const s = Math.max(0, track2[i].start); const e = Math.min(duration, track2[i].end);
      const out = `part_${i}.mp4`;
      let args;
      if (forceReencodeEl.checked){
        args = ['-ss', s.toFixed(3), '-to', e.toFixed(3), '-i', 'input.mp4', '-c:v','libx264','-preset','veryfast','-crf','23','-c:a','copy', out];
      } else if (smartCopyEl.checked){
        args = ['-ss', s.toFixed(3), '-to', e.toFixed(3), '-i', 'input.mp4', '-c','copy', out];
      } else {
        args = ['-ss', s.toFixed(3), '-to', e.toFixed(3), '-i', 'input.mp4', '-c:v','libx264','-preset','veryfast','-crf','23','-c:a','copy', out];
      }
      await runFFmpeg(args);
      parts.push(out);
    }

    // créer list.txt pour concat demuxer
    const listTxt = parts.map(p=>`file ${p}`).join('\n');
    ffmpeg.FS('writeFile','list.txt', new TextEncoder().encode(listTxt));

    const outName = 'track2.mp4';
    setStatus('Concaténation…');
    // concat demuxer (copy)
    await runFFmpeg(['-f','concat','-safe','0','-i','list.txt','-c','copy', outName]);
    downloadFromFS(outName, 'piste2.mp4');
    setStatus('Piste 2 exportée.');
  }));

  // ====== FFmpeg helpers ======
  async function ensureFFmpeg(){
    if (ffmpegLoaded) return;
    const { createFFmpeg } = window.FFmpeg;
    ffmpeg = createFFmpeg({ log: true, corePath: 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/ffmpeg-core.js' });
    ffmpeg.setLogger(({type,message})=>{ log(`[${type}] ${message}`); });
    setStatus('Chargement du moteur FFmpeg…');
    await ffmpeg.load();
    ffmpegLoaded = true; setStatus('Moteur FFmpeg chargé.');
  }
  async function runFFmpeg(args){ log(`$ ffmpeg ${args.join(' ')}`); await ffmpeg.run(...args); }
  function downloadFromFS(name, dlName){ const data = ffmpeg.FS('readFile', name); const blob = new Blob([data.buffer], {type:'video/mp4'}); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = dlName; a.click(); URL.revokeObjectURL(a.href); }
  function safeName(s){ return (s||'video').replace(/[^\w\-\u00C0-\u024F]+/g,'_').slice(0,64); }

  // ====== Raccourcis ======
  document.addEventListener('keydown',(e)=>{
    if (e.target && (e.target.tagName==='INPUT' || e.target.tagName==='TEXTAREA')) return;
    if (e.code==='Space'){ e.preventDefault(); if (videoEl.paused) videoEl.play(); else videoEl.pause(); }
    if (e.key==='m' || e.key==='M'){ const id=Math.random().toString(36).slice(2,9); markers.push({id,time:videoEl.currentTime||0}); renderMarkerList(); drawTimeline(); }
  });

})();
