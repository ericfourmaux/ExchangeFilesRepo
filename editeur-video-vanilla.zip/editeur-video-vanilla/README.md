# Éditeur Vidéo (Vanilla JavaScript)

Application **100% client** (HTML/CSS/JS) pour **Chrome** et **Firefox** permettant :

- Lecture d'une vidéo **MP4** et navigation **A–B** (boucle), marqueurs.
- **Copier/Coller** d'un segment A–B vers une **Piste 2** (assemblage multi-segments).
- **Export MP4** (H.264), via **FFmpeg.wasm** (CDN). Deux modes :
  - *Rapide* (**stream copy**) si possible (coupe sur images-clés) ;
  - *Fiable* (ré‑encodage vidéo **H.264**) avec `-preset veryfast -crf 23` et **copie audio**.
- **Édition des métadonnées MP4** (titre, artiste, album, année, commentaire) sans ré‑encodage.

> Conseillé pour des vidéos de **≤ 15 min**.

## Lancer

1. Ouvrez `index.html` dans Chrome/Firefox récents.
2. **Fichier → Ouvrir** pour choisir un MP4.
3. Placez **A** (Alt + clic sur timeline) et **B** (Shift + clic) ou utilisez les boutons.
4. **Lecture A–B** (Boucle optionnelle). **Copier** puis **Coller dans Piste 2**.
5. **Exporter segment** ou **Exporter Piste 2** en MP4.
6. Renseignez les **métadonnées** puis **Enregistrer MP4 + métadonnées** pour produire un MP4 « stream copy » avec tags mis à jour.

## Détails techniques & sources

- **FFmpeg.wasm** (WASM) est utilisé pour couper/concaténer/remuxer/ré‑encoder localement dans le navigateur. Pour de meilleures perfs (threads/SIMD), un déploiement avec en‑têtes COOP/COEP est recommandé ; ici l'exemple fonctionne sans ces en‑têtes mais peut être plus lent sur de longues exports. citeturn2search9turn2search10turn2search11turn2search14
- **WebCodecs** (option expérimentale) fournit l’accès bas niveau aux frames/chunks encodés (décodage/encodage matériel), mais ne gère pas le **muxing** conteneur, d’où l’intérêt d’un **muxer MP4** JS. (La démo embarque **mp4-muxer** en CDN si vous souhaitez étendre). citeturn2search3turn2search5turn2search16
- Pour la **prévisualisation** et les coupes temporelles, **MSE** permet de filtrer la fenêtre d’append via `appendWindowStart/End` (non utilisé dans le MVP, mais utile si vous itérez). citeturn2search27
- **Métadonnées MP4** : ajout/modification via `-metadata` et « stream copy » (pas de ré-encodage). citeturn2search34

## Limitations

- Les coupes **stream copy** (`-c copy`) sont **rapides** mais **précises seulement** si la coupe tombe sur une **image‑clé** ; sinon, utilisez le mode **ré‑encodage vidéo** qui est plus lent mais précis. citeturn2search30
- Les très longues vidéos peuvent être coûteuses en CPU/Mémoire dans le navigateur ; d’où la recommandation **≤ 15 min**.

## Licences & CDN

- **@ffmpeg/ffmpeg 0.12.x** via **unpkg**.
- **mp4box.js** (GPAC) et **mp4-muxer** (pour expérimentations WebCodecs/mp4) via **unpkg**.

## Astuces

- Pour de meilleures perfs avec FFmpeg.wasm, servez l’app avec en‑têtes :
  - `Cross-Origin-Opener-Policy: same-origin`
  - `Cross-Origin-Embedder-Policy: require-corp`
  (nécessaires aux **SharedArrayBuffer** et donc aux threads/SIMD). citeturn2search10
