// Niveau exemple via tableau (0=vide,1=solide)
const rows = 18, cols = 80;
const arr = [];
for (let r=0;r<rows;r++) {
  const row = [];
  for (let c=0;c<cols;c++) {
    // Sol en bas + quelques plateformes
    let t = 0;
    if (r === rows-2) t = 1;
    if (r === rows-6 && c%7<3) t = 1;
    row.push(t);
  }
  arr.push(row);
}
export default arr;
