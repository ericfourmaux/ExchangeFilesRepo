# Starter de jeu 2D en Vanilla JS (ES6 Modules + POO)

Ce projet fournit une **structure minimale mais complète** pour démarrer un jeu 2D côté client en **JavaScript vanilla** avec **classes** et **modules ES6**. Il inclut :

- Gestion de la **boucle de jeu**, **temps (delta/fps)** et **états** (écran titre, jeu, game over).
- **Entrées clavier** (WASD/flèches, saut, tir) avec `justPressed`.
- **Caméra** avec **scroll horizontal/vertical/multi** et **lerp**.
- **Sprites/sons** via chargeur d'assets.
- **Collisions** AABB/cercle/raycast et collisions tuiles pour le joueur/ennemis.
- **Décors**/niveaux chargeables depuis **Array**, **JSON**, ou **XML**.
- **UI** (score, énergie, vies).
- **Ennemis** avec IA de **poursuite** et **pathfinding A\*** sur grille.
- **Projectiles** et **pickups** (score/soin).

## Démarrage

> ⚠️ Les chargements `fetch()` de JSON/XML ne fonctionnent pas en `file://`. Utilisez un petit serveur local.

### Lancer un serveur local (au choix)

- **VS Code** : extension *Live Server*.
- **Node.js** : `npx serve` ou `npx http-server` dans le dossier du projet.
- **Python 3** :
  ```bash
  cd vanilla-js-game-starter
  python -m http.server 5173
  # ouvrez http://localhost:5173
  ```

Ensuite, ouvrez `index.html` via ce serveur.

## Contrôles

- Déplacements : **Flèches** ou **WASD**
- Saut : **Espace** (ou Z)
- Tir : **X** (ou Ctrl gauche)
- Menu titre : **↑ / ↓** pour choisir la difficulté, **Entrée** pour démarrer

## Structure

```
vanilla-js-game-starter/
  index.html
  styles.css
  assets/
    images/ (placeholders)
    sounds/ (placeholders)
  levels/
    level1.json
    level1.xml
    level-array.js
  src/
    main.js
    engine/
      Game.js, Time.js, Input.js, Renderer.js, Camera.js,
      assets/Assets.js, Collision.js, Sprite.js
    game/
      TitleScreen.js, Level.js, UI.js,
      Player.js, Enemy.js, Projectile.js, Pickup.js
    pathfinding/
      AStar.js
```

## Personnalisation rapide

- **Mode de scroll** : `new Camera({ scrollMode: 'horizontal' | 'vertical' | 'free', lerp: 0.12 })`.
- **Difficulté** : impacte le nombre d'ennemis.
- **Tuiles solides** : `1` dans les niveaux (0 = vide). Adaptez la logique dans `Level.solidTileAt`.
- **Sprites** : remplacez les images dans `assets/images/*.png`.
- **Sons** : remplacez `assets/sounds/*.wav`.

## Licence

Utilisation libre pour prototypage/apprentissage. Pas de garantie.
