// Niveau: chargement décor (array/JSON/XML), tuiles, collisions, entités
import { Enemy } from './Enemy.js';
import { Pickup } from './Pickup.js';

export class Level {
  constructor(game, { difficulty='normal' } = {}) {
    this.game = game;
    this.tileSize = 32;

    // Données du niveau
    this.cols = 64; this.rows = 32; // par défaut
    this.tiles = []; // 0=vide, 1=solide

    // Entités
    this.enemies = [];
    this.pickups = [];
    this.projectiles = [];

    this.playerSpawn = { x: 64, y: 64 };

    // Grille pour pathfinding (dérivée des tuiles)
    this.collisionGrid = [];

    // Limites du monde
    this.worldBounds = { x:0, y:0, w: this.cols*this.tileSize, h: this.rows*this.tileSize };

    // Choix difficulté (impacte nombre d'ennemis)
    this.difficulty = difficulty;

    // Chargement décor: tente JSON puis XML, sinon fallback array embarqué
    this.loadAll();
  }

  async loadAll() {
    let loaded = false;
    try {
      const res = await fetch('levels/level1.json');
      if (res.ok) {
        const json = await res.json();
        this.applyFromJSON(json);
        loaded = true;
      }
    } catch (e) { /* probablement local file */ }

    if (!loaded) {
      try {
        const res = await fetch('levels/level1.xml');
        if (res.ok) {
          const text = await res.text();
          this.applyFromXML(text);
          loaded = true;
        }
      } catch (e) {}
    }

    if (!loaded) {
      // Fallback: import dynamique depuis un array ESM
      try {
        const mod = await import('../../levels/level-array.js');
        this.applyFromArray(mod.default);
        loaded = true;
      } catch (e) {
        console.warn('Impossible de charger un niveau, génération d\'un niveau vide.');
        this.generateFlat();
      }
    }

    // Entités en fonction de la difficulté
    const count = this.difficulty === 'easy' ? 5 : this.difficulty === 'hard' ? 18 : 10;
    for (let i=0;i<count;i++) {
      const x = 200 + Math.random() * (this.worldBounds.w-400);
      const y = 100;
      const ai = i%2===0 ? 'chase' : 'path';
      this.enemies.push(new Enemy({ game: this.game, x, y, ai }));
    }

    // Quelques pickups
    for (let i=0;i<8;i++) {
      const x = 150 + i*220;
      const y = 220;
      this.pickups.push(new Pickup({ x, y, kind: i%3? 'score' : 'heal', value: i%3? 200:25 }));
    }
  }

  applyFromArray(arr) {
    this.rows = arr.length;
    this.cols = arr[0].length;
    this.tiles = arr.flat();
    this.postLoad();
  }

  applyFromJSON(json) {
    this.cols = json.cols; this.rows = json.rows; this.tileSize = json.tileSize || this.tileSize;
    this.tiles = json.tiles;
    this.playerSpawn = json.playerSpawn || this.playerSpawn;
    this.postLoad();
  }

  applyFromXML(xmlText) {
    // XML ultra simple: <level cols=".." rows=".." tileSize=".."><tiles>0,1,0,1,...</tiles></level>
    const parser = new DOMParser();
    const xml = parser.parseFromString(xmlText, 'application/xml');
    const level = xml.querySelector('level');
    this.cols = parseInt(level.getAttribute('cols'));
    this.rows = parseInt(level.getAttribute('rows'));
    this.tileSize = parseInt(level.getAttribute('tileSize')||this.tileSize);
    const tilesText = level.querySelector('tiles').textContent.trim();
    this.tiles = tilesText.split(/\s*,\s*/).map(Number);
    const spawn = level.querySelector('spawn');
    if (spawn) this.playerSpawn = { x: parseInt(spawn.getAttribute('x')), y: parseInt(spawn.getAttribute('y')) };
    this.postLoad();
  }

  generateFlat() {
    this.cols = 64; this.rows = 16; this.tileSize = 32;
    this.tiles = new Array(this.cols*this.rows).fill(0);
    // Bande solide en bas
    for (let c=0;c<this.cols;c++) this.tiles[(this.rows-2)*this.cols + c] = 1;
    this.postLoad();
  }

  postLoad() {
    this.worldBounds = { x:0, y:0, w: this.cols*this.tileSize, h: this.rows*this.tileSize };
    // Grille de collisions pour pathfinding
    this.collisionGrid = [];
    for (let r=0;r<this.rows;r++) {
      this.collisionGrid[r] = [];
      for (let c=0;c<this.cols;c++) {
        const idx = r*this.cols + c;
        this.collisionGrid[r][c] = this.tiles[idx] === 1 ? 1 : 0;
      }
    }
  }

  spawnPlayer(player) {
    player.x = this.playerSpawn.x;
    player.y = this.playerSpawn.y;
  }

  // Conversion monde->grille
  worldToGrid(x, y) {
    return { row: Math.floor(y/this.tileSize), col: Math.floor(x/this.tileSize) };
  }

  // Test si tuile solide à une position monde (x,y)
  solidTileAt(x, y) {
    const c = Math.floor(x/this.tileSize);
    const r = Math.floor(y/this.tileSize);
    if (c < 0 || r < 0 || c >= this.cols || r >= this.rows) return true; // hors limites = solide
    const t = this.tiles[r*this.cols + c];
    return t === 1;
  }

  update(game) {
    // Maj ennemis
    for (const e of this.enemies) e.update(game);
    this.enemies = this.enemies.filter(e => !e.dead);
  }

  render(r, camera) {
    // Rendu tuiles (simple rectangles si pas de tileset)
    const ts = this.tileSize;
    const img = this.game.assets.img('tileset');

    // Calcul des tuiles visibles pour performance
    const c0 = Math.max(0, Math.floor(camera.x/ts));
    const r0 = Math.max(0, Math.floor(camera.y/ts));
    const c1 = Math.min(this.cols-1, Math.floor((camera.x+camera.vw)/ts)+1);
    const r1 = Math.min(this.rows-1, Math.floor((camera.y+camera.vh)/ts)+1);

    for (let row=r0; row<=r1; row++) {
      for (let col=c0; col<=c1; col++) {
        const t = this.tiles[row*this.cols + col];
        if (t === 0) continue;
        const x = col*ts; const y = row*ts;
        if (img && img.width>1) r.drawImage(img, x, y, ts, ts, camera);
        else r.rect(x, y, ts, ts, '#455a64', camera);
      }
    }

    // Pickups
    for (const p of this.pickups) p.render(r, camera, this.game);

    // Ennemis
    for (const e of this.enemies) e.render(r, camera);

    // Projectiles
    for (const b of this.projectiles) b.render(r, camera);
  }
}
