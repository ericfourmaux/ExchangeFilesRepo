// Ecran d'accueil + choix de difficulté
export class TitleScreen {
  constructor(game) {
    this.menu = ['facile', 'normal', 'difficile'];
    this.index = 1;
    this.blink = 0;

    // Ecouteurs simples
    window.addEventListener('keydown', (e) => {
      if (game.state !== 'title') return;
      if (e.code === 'ArrowUp') this.index = (this.index + this.menu.length - 1) % this.menu.length;
      if (e.code === 'ArrowDown') this.index = (this.index + 1) % this.menu.length;
      if (e.code === 'Enter' || e.code === 'Space') {
        const diff = ['easy','normal','hard'][this.index];
        game.newGame(diff);
      }
    });
  }

  update(game) { this.blink += game.time.dt; }

  render(ctx) {
    const { canvas } = ctx;
    ctx.save();
    ctx.fillStyle = '#222';
    ctx.fillRect(0,0,canvas.width, canvas.height);

    ctx.fillStyle = '#fff';
    ctx.font = '32px monospace';
    ctx.textAlign = 'center';
    ctx.fillText('Starter Jeu 2D (ES6)', canvas.width/2, 80);

    ctx.font = '18px monospace';
    ctx.fillText('Utilisez ↑/↓ pour choisir la difficulté, Entrée pour jouer', canvas.width/2, 130);

    const options = ['facile','normal','difficile'];
    options.forEach((label, i) => {
      const y = 200 + i*28;
      ctx.fillStyle = (i===this.index) ? '#ffd54f' : '#bbb';
      ctx.fillText(label, canvas.width/2, y);
    });

    // Astuce clignotante
    if (Math.floor(this.blink*2)%2===0) {
      ctx.fillStyle = '#9e9e9e';
      ctx.fillText('Appuyez sur Entrée', canvas.width/2, 320);
    }

    ctx.restore();
  }
}
