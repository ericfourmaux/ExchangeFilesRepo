// Objet à ramasser (score/soin)
export class Pickup {
  constructor({ x, y, w=16, h=16, kind='score', value=100 }) {
    this.x = x; this.y = y; this.w = w; this.h = h;
    this.kind = kind;
    this.value = value;
    this.collected = false;
  }
  get rect() { return { x: this.x, y: this.y, w: this.w, h: this.h }; }
  collect(player) {
    this.collected = true;
    if (this.kind === 'score') player.score += this.value;
    if (this.kind === 'heal') player.hp = Math.min(100, player.hp + this.value);
  }
  render(r, camera, game) {
    const img = game.assets.img('pickup');
    if (!this.collected) {
      if (img && img.width>1) r.drawImage(img, this.x, this.y, this.w, this.h, camera);
      else r.rect(this.x, this.y, this.w, this.h, '#81c784', camera);
    }
  }
}
