// Ennemi basique: poursuite du joueur ou pathfinding A*
import { Collision } from '../engine/Collision.js';
import { aStar } from '../pathfinding/AStar.js';

export class Enemy {
  constructor({ game, x, y, w = 26, h = 26, ai = 'chase'}) {
    this.game = game;
    this.x = x; this.y = y; this.w = w; this.h = h;
    this.vx = 0; this.vy = 0;
    this.speed = 80;
    this.gravity = 900;
    this.onGround = false;
    this.ai = ai; // 'chase' | 'path'
    this.path = [];
    this.pathTimer = 0;
    this.dead = false;
  }

  get rect() { return { x: this.x, y: this.y, w: this.w, h: this.h }; }

  update(game) {
    const dt = game.time.dt;
    const level = game.level;
    const tiles = level.solidTileAt.bind(level);

    // IA
    if (this.ai === 'chase') {
      const target = game.player;
      const dx = target.x - this.x;
      this.vx = Math.sign(dx) * this.speed;
    } else if (this.ai === 'path') {
      // Recalcule un chemin toutes les 0.8s vers le joueur
      this.pathTimer -= dt;
      if (this.pathTimer <= 0) {
        this.pathTimer = 0.8;
        const grid = level.collisionGrid; // 0 libre, 1 solide
        const start = level.worldToGrid(this.x+this.w/2, this.y+this.h/2);
        const goal = level.worldToGrid(game.player.x+game.player.w/2, game.player.y+game.player.h/2);
        this.path = aStar(grid, start, goal);
      }
      // Suivre le chemin
      if (this.path && this.path.length) {
        const next = this.path[0];
        const wx = next.col*level.tileSize + level.tileSize/2;
        const wy = next.row*level.tileSize + level.tileSize/2;
        const dx = wx - (this.x+this.w/2);
        this.vx = Math.sign(dx) * this.speed;
        if (Math.abs(dx) < 6) this.path.shift();
      } else {
        this.vx = 0;
      }
    }

    // Gravité
    this.vy += this.gravity * dt;

    // Mouvements + collisions tuiles
    this.x += this.vx * dt;
    if (this.collideTiles(tiles)) {
      this.x -= this.vx * dt;
      while (!this.collideTiles(tiles)) this.x += Math.sign(this.vx||1) * 0.5;
      this.x -= Math.sign(this.vx||1) * 0.5;
      this.vx = 0;
    }

    this.y += this.vy * dt;
    const falling = this.vy > 0;
    if (this.collideTiles(tiles)) {
      this.y -= this.vy * dt;
      while (!this.collideTiles(tiles)) this.y += Math.sign(this.vy||1) * 0.5;
      this.y -= Math.sign(this.vy||1) * 0.5;
      this.onGround = falling;
      this.vy = 0;
    } else {
      this.onGround = false;
    }

    // Touché par projectile joueur
    for (const b of level.projectiles) {
      if (!b.dead && b.owner==='player' && Collision.aabbIntersect(this.rect, b.rect)) {
        this.dead = true;
        b.dead = true;
        game.player.score += 100;
      }
    }
  }

  collideTiles(solidTileAt) {
    const r = this.rect;
    const pad = 2;
    const corners = [
      { x: r.x+pad, y: r.y+pad },
      { x: r.x+r.w-pad, y: r.y+pad },
      { x: r.x+pad, y: r.y+r.h-pad },
      { x: r.x+r.w-pad, y: r.y+r.h-pad },
    ];
    for (const c of corners) if (solidTileAt(c.x, c.y)) return true;
    return false;
  }

  render(r, camera) {
    const img = this.game.assets.img('enemy');
    if (img && img.complete && img.width>1) {
      r.drawImage(img, this.x, this.y, this.w, this.h, camera);
    } else {
      r.rect(this.x, this.y, this.w, this.h, '#ef5350', camera);
    }
  }
}
