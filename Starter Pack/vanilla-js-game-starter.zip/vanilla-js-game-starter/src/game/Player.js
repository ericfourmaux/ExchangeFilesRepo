// Entité Joueur: déplacement, saut, tirs, collisions tuiles
import { Collision } from '../engine/Collision.js';
import { Projectile } from './Projectile.js';

export class Player {
  constructor({ game, x, y, w = 26, h = 30 }) {
    this.game = game;
    this.x = x; this.y = y; this.w = w; this.h = h;
    this.vx = 0; this.vy = 0;
    this.speed = 140; // px/s
    this.jumpStrength = 300;
    this.gravity = 900;
    this.onGround = false;
    this.facing = 1;

    this.hp = 100; // énergie
    this.lives = 3;
    this.score = 0;
    this.fireCooldown = 0;
  }

  get rect() { return { x: this.x, y: this.y, w: this.w, h: this.h }; }

  update(game) {
    const dt = game.time.dt;
    const inp = game.input;

    // Contrôles horizontaux
    const left = inp.isDown('LEFT');
    const right = inp.isDown('RIGHT');
    this.vx = 0;
    if (left) this.vx -= this.speed;
    if (right) this.vx += this.speed;
    if (right && !left) this.facing = 1; else if (left && !right) this.facing = -1;

    // Gravité
    this.vy += this.gravity * dt;

    // Saut
    if (inp.justPressed('JUMP') && this.onGround) {
      this.vy = -this.jumpStrength;
      game.assets.snd('jump')?.cloneNode()?.play();
    }

    // Tirs
    this.fireCooldown -= dt;
    if (inp.isDown('SHOOT') && this.fireCooldown <= 0) {
      this.shoot();
      this.fireCooldown = 0.25;
    }

    // Mouvement + collisions tuiles (simple AABB vs tuiles solides)
    const level = game.level;
    const tiles = level.solidTileAt.bind(level);

    // Déplacement axe X
    this.x += this.vx * dt;
    if (this.collideTiles(tiles)) {
      // Résolution: reculer
      this.x -= this.vx * dt;
      while (!this.collideTiles(tiles)) this.x += Math.sign(this.vx || this.facing) * 0.5; // approche fine
      this.x -= Math.sign(this.vx || this.facing) * 0.5;
      this.vx = 0;
    }

    // Déplacement axe Y
    this.y += this.vy * dt;
    const wasFalling = this.vy > 0;
    if (this.collideTiles(tiles)) {
      this.y -= this.vy * dt;
      while (!this.collideTiles(tiles)) this.y += Math.sign(this.vy || 1) * 0.5;
      this.y -= Math.sign(this.vy || 1) * 0.5;
      // Si on tombait et on touche en bas => au sol
      this.onGround = wasFalling;
      this.vy = 0;
    } else {
      this.onGround = false;
    }

    // Collisions avec pickups
    for (const p of level.pickups) {
      if (!p.collected && Collision.aabbIntersect(this.rect, p.rect)) {
        p.collect(this);
        game.assets.snd('pickup')?.cloneNode()?.play();
      }
    }

    // Collisions avec ennemis
    for (const e of level.enemies) {
      if (!e.dead && Collision.aabbIntersect(this.rect, e.rect)) {
        this.takeDamage(10);
      }
    }

    // Mise à jour des tirs
    for (const b of level.projectiles) b.update(game);
    level.projectiles = level.projectiles.filter(b => !b.dead);
  }

  collideTiles(solidTileAt) {
    const r = this.rect;
    const pad = 2;
    const corners = [
      { x: r.x+pad, y: r.y+pad },
      { x: r.x+r.w-pad, y: r.y+pad },
      { x: r.x+pad, y: r.y+r.h-pad },
      { x: r.x+r.w-pad, y: r.y+r.h-pad },
    ];
    for (const c of corners) if (solidTileAt(c.x, c.y)) return true;
    return false;
  }

  shoot() {
    const dir = this.facing;
    const bullet = new Projectile({
      x: this.x + this.w/2 + dir*14,
      y: this.y + this.h/2,
      vx: dir * 380,
      vy: 0,
      owner: 'player'
    });
    this.game.level.projectiles.push(bullet);
    this.game.assets.snd('shoot')?.cloneNode()?.play();
  }

  takeDamage(dmg) {
    this.hp -= dmg;
    if (this.hp <= 0) {
      this.lives -= 1;
      if (this.lives < 0) {
        this.game.state = 'gameover';
      } else {
        // Respawn simple
        this.hp = 100;
        const spawn = this.game.level.playerSpawn || {x:64,y:64};
        this.x = spawn.x; this.y = spawn.y;
        this.vx = this.vy = 0;
      }
    }
  }

  render(r, camera) {
    const img = this.game.assets.img('player');
    if (img && img.complete && img.width>1) {
      r.drawImage(img, this.x, this.y, this.w, this.h, camera);
    } else {
      r.rect(this.x, this.y, this.w, this.h, '#4fc3f7', camera);
    }
  }
}
