// Projectile linéaire simple
import { Collision } from '../engine/Collision.js';

export class Projectile {
  constructor({ x, y, vx = 0, vy = 0, r = 4, owner = 'player' }) {
    this.x = x - r; this.y = y - r; this.r = r; // stocké comme cercle avec x/y = coin pour compat
    this.vx = vx; this.vy = vy;
    this.owner = owner;
    this.dead = false;
  }
  get rect() { return { x: this.x, y: this.y, w: this.r*2, h: this.r*2 }; }
  update(game) {
    const dt = game.time.dt;
    this.x += this.vx * dt;
    this.y += this.vy * dt;

    // Mort si touche une tuile solide
    if (game.level.solidTileAt(this.x+this.r, this.y+this.r)) this.dead = true;

    // Sortie du monde
    const b = game.level.worldBounds;
    if (this.x < 0 || this.y < 0 || this.x > b.w || this.y > b.h) this.dead = true;
  }
  render(r, camera) {
    r.rect(this.x, this.y, this.r*2, this.r*2, '#ffd54f', camera);
  }
}
