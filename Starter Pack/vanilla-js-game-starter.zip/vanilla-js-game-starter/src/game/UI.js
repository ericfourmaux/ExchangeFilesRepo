// Interface utilisateur (score, énergie, vies)
export class UI {
  constructor(){}
  update(game){}
  render(ctx, game) {
    ctx.save();
    ctx.fillStyle = '#fff';
    ctx.font = '16px monospace';
    ctx.textBaseline = 'top';
    ctx.fillText(`Score: ${game.player?.score ?? 0}`, 10, 10);
    ctx.fillText(`Energie: ${game.player?.hp ?? 0}`, 10, 30);
    ctx.fillText(`Vies: ${game.player?.lives ?? 0}`, 10, 50);
    ctx.restore();
  }
}
