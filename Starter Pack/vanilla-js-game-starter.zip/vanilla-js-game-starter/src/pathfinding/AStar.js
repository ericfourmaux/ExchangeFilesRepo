// A* sur grille (4 directions)
export function aStar(grid, start, goal) {
  const rows = grid.length, cols = grid[0].length;
  const inBounds = (r,c)=> r>=0 && c>=0 && r<rows && c<cols;
  const passable = (r,c)=> grid[r][c]===0;
  const key = (r,c)=> r+','+c;

  const open = new Map();
  const came = new Map();
  const g = new Map();

  function h(r,c){ return Math.abs(r-goal.row)+Math.abs(c-goal.col); }

  const k0 = key(start.row,start.col);
  g.set(k0, 0);
  open.set(k0, { row:start.row, col:start.col, f: h(start.row,start.col) });

  while (open.size) {
    // extraire le plus petit f
    let bestK=null, best=null;
    for (const [k,node] of open) { if (!best || node.f < best.f) { best=node; bestK=k; } }
    open.delete(bestK);

    if (best.row===goal.row && best.col===goal.col) {
      // reconstruit
      const path=[]; let curK=bestK;
      while (curK) {
        const [r,c] = curK.split(',').map(Number);
        path.unshift({ row:r, col:c });
        curK = came.get(curK);
      }
      path.shift(); // retire la case de départ
      return path;
    }

    const dirs=[[1,0],[-1,0],[0,1],[0,-1]];
    for (const [dr,dc] of dirs) {
      const nr=best.row+dr, nc=best.col+dc;
      if (!inBounds(nr,nc) || !passable(nr,nc)) continue;
      const nk = key(nr,nc);
      const tentative = (g.get(bestK)??Infinity) + 1;
      if (tentative < (g.get(nk)??Infinity)) {
        came.set(nk, bestK);
        g.set(nk, tentative);
        open.set(nk, { row:nr, col:nc, f: tentative + h(nr,nc) });
      }
    }
  }

  return [];
}
