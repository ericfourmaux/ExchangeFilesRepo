// Aide au rendu (sprites, tuiles)
export class Renderer {
  constructor(ctx) {
    this.ctx = ctx;
  }

  // Dessin d'une image avec décalage caméra
  drawImage(img, x, y, w, h, camera) {
    const cx = Math.floor(x - camera.x);
    const cy = Math.floor(y - camera.y);
    this.ctx.drawImage(img, cx, cy, w, h);
  }

  // Dessin d'un rectangle (fallback debug)
  rect(x, y, w, h, color, camera) {
    const cx = Math.floor(x - camera.x);
    const cy = Math.floor(y - camera.y);
    this.ctx.fillStyle = color;
    this.ctx.fillRect(cx, cy, w, h);
  }
}
