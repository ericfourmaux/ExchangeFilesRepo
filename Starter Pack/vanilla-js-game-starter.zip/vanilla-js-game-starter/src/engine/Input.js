// Gestion clavier (et potentiellement gamepad)
const KEYMAP = {
  LEFT: ['ArrowLeft', 'KeyA'],
  RIGHT: ['ArrowRight', 'KeyD'],
  UP: ['ArrowUp', 'KeyW'],
  DOWN: ['ArrowDown', 'KeyS'],
  JUMP: ['Space', 'KeyZ'],
  SHOOT: ['KeyX', 'ControlLeft']
};

export class Input {
  constructor() {
    this.keys = new Set();
    this.pressed = new Set(); // pour détection "just pressed"
    this.released = new Set();

    window.addEventListener('keydown', (e) => {
      if (!e.repeat) {
        this.keys.add(e.code);
        this.pressed.add(e.code);
      }
    });

    window.addEventListener('keyup', (e) => {
      this.keys.delete(e.code);
      this.released.add(e.code);
    });
  }

  update() {
    // Nettoyage des flags après la frame
    this.pressed.clear();
    this.released.clear();
  }

  isDown(action) {
    return KEYMAP[action].some(c => this.keys.has(c));
  }

  justPressed(action) {
    return KEYMAP[action].some(c => this.pressed.has(c));
  }

  justReleased(action) {
    return KEYMAP[action].some(c => this.released.has(c));
  }
}
