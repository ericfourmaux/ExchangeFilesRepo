// Gestion du temps et du delta
export class Time {
  constructor() {
    this.last = performance.now();
    this.dt = 0; // en secondes
    this.fps = 60;
  }
  update() {
    const now = performance.now();
    this.dt = (now - this.last) / 1000;
    this.last = now;
    // Lissage du FPS
    const currentFps = 1 / Math.max(this.dt, 1/120);
    this.fps = this.fps * 0.9 + currentFps * 0.1;
  }
}
