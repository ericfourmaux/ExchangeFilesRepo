// Chargement d'assets (images/sons)
export class Assets {
  constructor() {
    this.images = new Map();
    this.audio = new Map();
  }

  async loadImage(key, url) {
    const img = new Image();
    img.src = url;
    await img.decode().catch(() => {});
    this.images.set(key, img);
    return img;
  }

  async loadAudio(key, url) {
    return new Promise((resolve) => {
      const a = new Audio();
      a.src = url;
      a.addEventListener('canplaythrough', () => resolve(a), { once: true });
      a.addEventListener('error', () => resolve(a), { once: true });
      this.audio.set(key, a);
    });
  }

  async loadBulk({ images = {}, audio = {} }) {
    const tasks = [];
    for (const [k, url] of Object.entries(images)) tasks.push(this.loadImage(k, url));
    for (const [k, url] of Object.entries(audio)) tasks.push(this.loadAudio(k, url));
    await Promise.all(tasks);
  }

  img(key) { return this.images.get(key); }
  snd(key) { return this.audio.get(key); }
}
