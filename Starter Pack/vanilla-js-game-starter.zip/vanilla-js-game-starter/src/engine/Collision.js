// Détection de collisions (AABB, cercle, AABB<->cercle, raycast simple)
export const Collision = {
  aabbIntersect(a, b) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  },

  circleIntersect(a, b) {
    const dx = (a.x + a.r) - (b.x + b.r);
    const dy = (a.y + a.r) - (b.y + b.r);
    const d2 = dx*dx + dy*dy;
    const r = a.r + b.r;
    return d2 <= r*r;
  },

  aabbCircleIntersect(a, c) {
    const cx = c.x + c.r;
    const cy = c.y + c.r;
    const closestX = Math.max(a.x, Math.min(cx, a.x + a.w));
    const closestY = Math.max(a.y, Math.min(cy, a.y + a.h));
    const dx = cx - closestX;
    const dy = cy - closestY;
    return (dx*dx + dy*dy) <= c.r*c.r;
  },

  // Raycast très simple contre une liste de segments [{x1,y1,x2,y2}]
  raycast(x1,y1,x2,y2, segments) {
    let hit = null;
    let closestT = Infinity;
    for (const s of segments) {
      const res = Collision._raySeg(x1,y1,x2,y2, s.x1,s.y1,s.x2,s.y2);
      if (res && res.t < closestT) { closestT = res.t; hit = res; }
    }
    return hit; // {x,y,t}
  },

  _raySeg(x1,y1,x2,y2, x3,y3,x4,y4) {
    const den = (x1-x2)*(y3-y4) - (y1-y2)*(x3-x4);
    if (den === 0) return null;
    const t = ((x1-x3)*(y3-y4) - (y1-y3)*(x3-x4)) / den;
    const u = -((x1-x2)*(y1-y3) - (y1-y2)*(x1-x3)) / den;
    if (t >= 0 && t <= 1 && u >= 0 && u <= 1) {
      return { x: x1 + t*(x2-x1), y: y1 + t*(y2-y1), t };
    }
    return null;
  }
};
