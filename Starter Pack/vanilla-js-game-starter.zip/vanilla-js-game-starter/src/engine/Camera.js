// Caméra 2D avec scroll horizontal/vertical/libre + lerp
export class Camera {
  constructor({ viewportWidth, viewportHeight, scrollMode = 'free', lerp = 0.15 }) {
    this.vw = viewportWidth;
    this.vh = viewportHeight;
    this.scrollMode = scrollMode; // 'horizontal' | 'vertical' | 'free'
    this.lerpFactor = lerp;

    this.x = 0; this.y = 0;
  }

  setMode(mode) { this.scrollMode = mode; }

  // Suit une cible (x,y,w,h) et respecte les limites du monde
  follow(target, bounds) {
    const targetX = target.x + target.w/2 - this.vw/2;
    const targetY = target.y + target.h/2 - this.vh/2;

    // Lerp pour un mouvement fluide
    const lerp = (a,b,t)=>a+(b-a)*t;

    if (this.scrollMode === 'horizontal') {
      this.x = lerp(this.x, targetX, this.lerpFactor);
    } else if (this.scrollMode === 'vertical') {
      this.y = lerp(this.y, targetY, this.lerpFactor);
    } else { // free
      this.x = lerp(this.x, targetX, this.lerpFactor);
      this.y = lerp(this.y, targetY, this.lerpFactor);
    }

    // Clamp dans les bornes du monde
    if (bounds) {
      const maxX = Math.max(0, bounds.w - this.vw);
      const maxY = Math.max(0, bounds.h - this.vh);
      this.x = Math.min(Math.max(0, this.x), maxX);
      this.y = Math.min(Math.max(0, this.y), maxY);
    }
  }
}
