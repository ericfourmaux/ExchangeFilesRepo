// Gestion globale du jeu (boucle, états, ressources)
import { Time } from './Time.js';
import { Input } from './Input.js';
import { Assets } from './assets/Assets.js';
import { Renderer } from './Renderer.js';
import { Camera } from './Camera.js';
import { TitleScreen } from '../game/TitleScreen.js';
import { Level } from '../game/Level.js';
import { UI } from '../game/UI.js';
import { Player } from '../game/Player.js';

export class Game {
  /**
   * @param {{canvas: HTMLCanvasElement}} opts
   */
  constructor({ canvas }) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');

    this.time = new Time();
    this.input = new Input();
    this.assets = new Assets();
    this.renderer = new Renderer(this.ctx);

    // Caméra avec scrolling multidirectionnel + lerp
    this.camera = new Camera({
      viewportWidth: canvas.width,
      viewportHeight: canvas.height,
      scrollMode: 'free', // 'horizontal' | 'vertical' | 'free'
      lerp: 0.12,
    });

    // États possibles: 'loading' | 'title' | 'playing' | 'gameover'
    this.state = 'loading';

    // UI
    this.ui = new UI();

    // Données de difficulté courantes
    this.difficulty = 'normal';

    // Monde courant
    this.level = null;
    this.player = null;

    // Pour debug
    this.debugEl = document.getElementById('debug');

    // Pré-chargement de quelques assets (sprites et sons)
    this.preload();
  }

  async preload() {
    try {
      await this.assets.loadBulk({
        images: {
          // Placeholders 1x1 (peuvent être remplacés par de vrais sprites)
          'player': 'assets/images/player.png',
          'enemy': 'assets/images/enemy.png',
          'pickup': 'assets/images/pickup.png',
          'tileset': 'assets/images/tileset.png'
        },
        audio: {
          'jump': 'assets/sounds/jump.wav',
          'pickup': 'assets/sounds/pickup.wav',
          'shoot': 'assets/sounds/shoot.wav'
        }
      });
    } catch (e) {
      console.warn('Erreur de chargement des assets (placeholders utilisés):', e);
    }

    // Une fois le chargement terminé, on affiche l'écran titre
    this.title = new TitleScreen(this);
    this.state = 'title';
  }

  start() {
    const loop = (t) => {
      requestAnimationFrame(loop);
      this.update();
      this.render();
    };
    requestAnimationFrame(loop);
  }

  newGame(difficulty) {
    this.difficulty = difficulty || 'normal';
    this.level = new Level(this, { difficulty: this.difficulty });

    // Création du joueur
    this.player = new Player({
      game: this,
      x: 64, y: 64,
      w: 26, h: 30,
    });

    this.level.spawnPlayer(this.player);

    this.state = 'playing';
  }

  update() {
    this.time.update();
    this.input.update();

    if (this.state === 'title') {
      this.title.update(this);
      return;
    }

    if (this.state === 'playing') {
      // Mise à jour du monde
      this.level?.update(this);
      this.player?.update(this);

      // Caméra suit le joueur
      if (this.player) {
        this.camera.follow(this.player, this.level.worldBounds);
      }

      // UI
      this.ui.update(this);
    }
  }

  render() {
    const ctx = this.ctx;
    const { width, height } = this.canvas;

    // Effacer l'écran
    ctx.clearRect(0, 0, width, height);
    ctx.fillStyle = '#0b0b0b';
    ctx.fillRect(0, 0, width, height);

    if (this.state === 'title') {
      this.title.render(ctx);
      return;
    }

    if (this.state === 'playing') {
      // Décors et entités
      this.level?.render(this.renderer, this.camera);
      this.player?.render(this.renderer, this.camera);

      // UI par-dessus
      this.ui.render(ctx, this);
    }

    // Debug basique
    if (this.debugEl) {
      this.debugEl.textContent = `FPS: ${this.time.fps.toFixed(0)} | Etat: ${this.state} | Diff: ${this.difficulty}`;
    }
  }
}
