// Sprite/Animation de base (spritesheet)
export class Sprite {
  /**
   * @param {HTMLImageElement} image
   * @param {{fw:number, fh:number, frames:number, fps:number}} opts taille frame
   */
  constructor(image, { fw, fh, frames = 1, fps = 8 } = {}) {
    this.image = image;
    this.fw = fw || image.width;
    this.fh = fh || image.height;
    this.frames = frames;
    this.fps = fps;
    this.time = 0;
    this.current = 0;
  }
  update(dt) {
    if (this.frames <= 1) return;
    this.time += dt;
    if (this.time >= 1 / this.fps) {
      this.time = 0;
      this.current = (this.current + 1) % this.frames;
    }
  }
  draw(ctx, x, y, w, h, camera) {
    const sx = this.current * this.fw;
    const sy = 0;
    const cx = Math.floor(x - camera.x);
    const cy = Math.floor(y - camera.y);
    ctx.drawImage(this.image, sx, sy, this.fw, this.fh, cx, cy, w, h);
  }
}
