# Starter de jeu 2D – Parallax + Triggers (Vanilla JS, ES6, POO)

Cette v2 ajoute :

- **Parallax multi-couches** (défilement indépendant par couche, tiling horizontal/vertical, facteur de vitesse, échelle, couleur fallback).
- **Zones de trigger** rectangulaires (onEnter) avec actions génériques : `message`, `heal`, `score`, `cameraMode`, `spawn`.

Le reste de la base (joueur, ennemis IA poursuite/A*, collisions, tuiles, UI, écran titre, assets) est conservé.

## Lancer

Servez le dossier :
```bash
python -m http.server 5173
# ouvrez http://localhost:5173
```

## Configurer le parallax

- Dans `levels/level1.json` :
```json
"parallax": [
  {"imageKey":"bg1","speedX":0.15,"scale":2},
  {"imageKey":"bg2","speedX":0.35,"scale":2},
  {"imageKey":"bg3","speedX":0.60,"scale":2}
]
```
- Chaque couche supporte : `imageKey`, `speedX`, `speedY`, `tileX`, `tileY`, `offsetX`, `offsetY`, `scale`, `color`.

## Déclarer des triggers

- JSON :
```json
{"x":400,"y":288,"w":64,"h":48,"type":"message","data":{"text":"Bienvenue"}}
```
- XML :
```xml
<trigger x="500" y="256" w="64" h="48" type="message" data='{"text":"Zone XML"}' />
```
- Types disponibles :
  - `message` → `data.text`, `data.duration`
  - `heal` → `data.amount`
  - `score` → `data.points`
  - `cameraMode` → `data.mode` (`horizontal`, `vertical`, `free`)
  - `spawn` → `data.count`, `data.ai`

## Astuces
- Active le debug visuel des triggers en décommentant `renderDebug` dans `Level.render()`.
- Pour une parallaxe verticale (plateformers avec défilement vertical), utilise `speedY`.
- Remplace `assets/images/bg*.png` par de vrais backgrounds (tileables de préférence).
