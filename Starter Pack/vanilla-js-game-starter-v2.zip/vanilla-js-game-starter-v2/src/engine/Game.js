// Gestion globale du jeu (boucle, états, ressources)
import { Time } from './Time.js';
import { Input } from './Input.js';
import { Assets } from './assets/Assets.js';
import { Renderer } from './Renderer.js';
import { Camera } from './Camera.js';
import { TitleScreen } from '../game/TitleScreen.js';
import { Level } from '../game/Level.js';
import { UI } from '../game/UI.js';
import { Player } from '../game/Player.js';

export class Game {
  constructor({ canvas }) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');

    this.time = new Time();
    this.input = new Input();
    this.assets = new Assets();
    this.renderer = new Renderer(this.ctx);

    this.camera = new Camera({
      viewportWidth: canvas.width,
      viewportHeight: canvas.height,
      scrollMode: 'free',
      lerp: 0.12,
    });

    this.state = 'loading';
    this.ui = new UI();
    this.difficulty = 'normal';

    this.level = null;
    this.player = null;

    this.debugEl = document.getElementById('debug');

    this.preload();
  }

  async preload() {
    try {
      await this.assets.loadBulk({
        images: {
          'player': 'assets/images/player.png',
          'enemy': 'assets/images/enemy.png',
          'pickup': 'assets/images/pickup.png',
          'tileset': 'assets/images/tileset.png',
          'bg1': 'assets/images/bg1.png',
          'bg2': 'assets/images/bg2.png',
          'bg3': 'assets/images/bg3.png'
        },
        audio: {
          'jump': 'assets/sounds/jump.wav',
          'pickup': 'assets/sounds/pickup.wav',
          'shoot': 'assets/sounds/shoot.wav'
        }
      });
    } catch (e) {
      console.warn('Erreur de chargement des assets (placeholders utilisés):', e);
    }

    this.title = new TitleScreen(this);
    this.state = 'title';
  }

  start() {
    const loop = () => {
      requestAnimationFrame(loop);
      this.update();
      this.render();
    };
    requestAnimationFrame(loop);
  }

  newGame(difficulty) {
    this.difficulty = difficulty || 'normal';
    this.level = new Level(this, { difficulty: this.difficulty });

    this.player = new Player({ game: this, x: 64, y: 64, w: 26, h: 30 });
    this.level.spawnPlayer(this.player);

    this.state = 'playing';
  }

  update() {
    this.time.update();
    this.input.update();

    if (this.state === 'title') {
      this.title.update(this);
      return;
    }

    if (this.state === 'playing') {
      this.level?.update(this);
      this.player?.update(this);

      if (this.player) this.camera.follow(this.player, this.level.worldBounds);

      this.ui.update(this);
    }
  }

  render() {
    const ctx = this.ctx;
    const { width, height } = this.canvas;

    ctx.clearRect(0, 0, width, height);

    if (this.state === 'title') {
      this.title.render(ctx);
      return;
    }

    if (this.state === 'playing') {
      this.level?.render(this.renderer, this.camera);
      this.player?.render(this.renderer, this.camera);
      this.ui.render(ctx, this);
    }

    if (this.debugEl) {
      this.debugEl.textContent = `FPS: ${this.time.fps.toFixed(0)} | Etat: ${this.state} | Diff: ${this.difficulty}`;
    }
  }

  handleTrigger(trigger) {
    const t = trigger;
    switch (t.type) {
      case 'message': {
        const text = t.data?.text || 'Message';
        this.ui.show(text, t.data?.duration || 2);
        break;
      }
      case 'heal': {
        const amount = t.data?.amount || 20;
        if (this.player) this.player.hp = Math.min(100, this.player.hp + amount);
        this.ui.show(`+${amount} énergie`, 1.5);
        break;
      }
      case 'score': {
        const pts = t.data?.points || 500;
        if (this.player) this.player.score += pts;
        this.ui.show(`+${pts} points`, 1.5);
        break;
      }
      case 'cameraMode': {
        const mode = t.data?.mode || 'free';
        this.camera.setMode(mode);
        this.ui.show(`Caméra: ${mode}`, 1.2);
        break;
      }
      case 'spawn': {
        const n = t.data?.count || 3;
        const ai = t.data?.ai || 'chase';
        for (let i = 0; i < n; i++) {
          const x = t.x + (i*24);
          const y = t.y - 24;
          this.level.spawnEnemy({ x, y, ai });
        }
        this.ui.show(`Ambush! (${n})`, 1.2);
        break;
      }
      default:
        console.log('Trigger inconnu:', t.type, t);
    }
  }
}
