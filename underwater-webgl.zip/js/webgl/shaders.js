export const vertexShaderSource = `
attribute vec2 a_position;
varying vec2 v_uv;
void main(){
  v_uv = a_position * 0.5 + 0.5;
  gl_Position = vec4(a_position, 0.0, 1.0);
}`;

export const fragmentShaderSource = `
precision highp float;
uniform sampler2D u_image;
uniform float u_depth;
varying vec2 v_uv;

vec3 sCurve(vec3 c, float k){
  float mid = 0.5;
  vec3 r = 1.0 / (1.0 + exp(-k * (c - mid)));
  float a = 1.0 / (1.0 + exp(k * mid));
  float b = 1.0 / (1.0 + exp(-k * (1.0 - mid)));
  return clamp((r - a) / (b - a), 0.0, 1.0);
}

void main(){
  vec3 col = texture2D(u_image, v_uv).rgb;

  float redGain = mix(1.2, 3.5, u_depth);
  float greenSupp = mix(0.05, 0.35, u_depth);
  float contrast = mix(1.0, 2.8, u_depth);

  col.r = pow(min(1.0, col.r * redGain), 0.9);

  float avgRB = (col.r + col.b) * 0.5;
  if (col.g > avgRB) {
    col.g = mix(col.g, avgRB, greenSupp);
  }

  col = sCurve(col, contrast);
  gl_FragColor = vec4(col, 1.0);
}`;