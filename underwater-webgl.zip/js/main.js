import { initProgressBar } from './ui/progressBar.js';
import { processVideo } from './core/videoProcessor.js';

const update = initProgressBar();
const input = document.getElementById('fileInput');

input.onchange = async () => {
  const file = input.files[0];
  if (!file) return;

  if (file.type.startsWith('video/')) {
    const video = document.createElement('video');
    video.src = URL.createObjectURL(file);
    await video.play();
    video.pause();

    const blob = await processVideo(video, update);
    const url = URL.createObjectURL(blob);

    const btn = document.getElementById('download');
    btn.hidden = false;
    btn.onclick = () => {
      const a = document.createElement('a');
      a.href = url;
      a.download = 'corrected.webm';
      a.click();
    };
  }
};