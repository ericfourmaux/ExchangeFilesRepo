export function initProgressBar(){
  const root = document.getElementById('progress');
  const container = document.createElement('div');
  const bar = document.createElement('div');
  const label = document.createElement('div');

  container.style.background = '#ccc';
  container.style.height = '24px';
  bar.style.height = '24px';
  bar.style.width = '0%';
  bar.style.background = '#4caf50';

  container.appendChild(bar);
  root.append(container, label);

  return ({ percent, eta }) => {
    bar.style.width = percent + '%';
    label.textContent = `${percent}% – Temps restant estimé : ${eta}s`;
  };
}