export function createTimeEstimator(){
  const samples = [];
  return (dt, remaining) => {
    samples.push(dt);
    if (samples.length > 30) samples.shift();
    const avg = samples.reduce((a,b)=>a+b,0)/samples.length;
    return avg * remaining;
  };
}