export function estimateDepth(imageData){
  const d = imageData.data;
  let r = 0, g = 0, b = 0;

  for (let i = 0; i < d.length; i += 4) {
    r += d[i];
    g += d[i + 1];
    b += d[i + 2];
  }

  const rg = r / (g + 1);
  const rb = r / (b + 1);
  return Math.max(0, Math.min(1, 1 - Math.min(1, (rg + rb) * 0.5)));
}