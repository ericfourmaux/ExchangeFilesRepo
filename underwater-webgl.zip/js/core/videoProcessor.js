import { applyWebGLFilter } from '../webgl/glRenderer.js';
import { estimateDepth } from './depthEstimator.js';
import { createTimeEstimator } from './timeEstimator.js';

export async function processVideo(video, onProgress) {
  const fps = 30;
  const totalFrames = Math.floor(video.duration * fps);

  const canvas = document.createElement('canvas');
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext('2d');

  const stream = canvas.captureStream(fps);
  const recorder = new MediaRecorder(stream);
  const chunks = [];
  recorder.ondataavailable = e => chunks.push(e.data);
  recorder.start();

  const estimate = createTimeEstimator();
  let processed = 0;

  for (let i = 0; i < totalFrames; i++) {
    const start = performance.now();

    video.currentTime = i / fps;
    await new Promise(r => video.onseeked = r);

    ctx.drawImage(video, 0, 0);
    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const depth = estimateDepth(imgData);

    const bitmap = await createImageBitmap(canvas);
    const outCanvas = applyWebGLFilter(bitmap, depth);
    ctx.drawImage(outCanvas, 0, 0);

    processed++;
    const dt = (performance.now() - start) / 1000;
    const eta = estimate(dt, totalFrames - processed);

    onProgress({
      percent: Math.round((processed / totalFrames) * 100),
      eta: Math.round(eta)
    });

    await new Promise(r => requestAnimationFrame(r));
  }

  recorder.stop();
  return new Promise(r => recorder.onstop = () => r(new Blob(chunks)));
}