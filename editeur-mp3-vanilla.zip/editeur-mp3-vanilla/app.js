// Éditeur MP3 en Vanilla JS
// - Lecture/pauses via Web Audio API
// - Affichage forme d'onde Canvas + zoom
// - Marqueurs, sélection A–B, lecture A–B (loop)
// - Copie/coller de segments vers Piste 2, export WAV
// - Lecture/écriture de métadonnées ID3 (lecture v2.3/v2.4, écriture v2.3 UTF-16)

(function(){
  'use strict';

  // ====== Sélecteurs ======
  const fileInput = document.getElementById('fileInput');
  const statusEl = document.getElementById('status');
  const waveCanvas = document.getElementById('waveCanvas');
  const track2Canvas = document.getElementById('track2Canvas');
  const ctxWave = waveCanvas.getContext('2d');
  const ctxT2 = track2Canvas.getContext('2d');
  const currentTimeEl = document.getElementById('currentTime');
  const totalTimeEl = document.getElementById('totalTime');
  const markerListEl = document.getElementById('markerList');
  const zoomEl = document.getElementById('zoom');
  const markerAEl = document.getElementById('markerA');
  const markerBEl = document.getElementById('markerB');
  const loopABEl = document.getElementById('loopAB');
  const fileInfoEl = document.getElementById('fileInfo');

  const tagForm = document.getElementById('tagForm');

  // ====== Audio state ======
  let audioCtx = null;  // AudioContext
  let buffer = null;    // AudioBuffer original
  let source = null;    // BufferSource en cours
  let startTime = 0;    // perf.now() quand play
  let startOffset = 0;  // offset (s) dans le buffer au démarrage
  let playing = false;

  let zoom = 1; // facteur de zoom horizontal

  // MP3 binaire (ArrayBuffer) + infos tag
  let originalMp3 = null;
  let audioDataBytes = null; // Uint8Array sans tag v2
  let id3Read = {};          // tags lus

  // Marqueurs et sélection
  let markers = []; // {id, time}
  let selectedMarkerId = null;
  let A = null, B = null; // seconds

  // Piste 2 (segments collés)
  let track2 = []; // {buffer: AudioBuffer}

  
  function selectionValid(){
    return buffer && A!=null && B!=null && Math.max(A,B) > Math.min(A,B);
  }
  function updateSelectionButtons(){
    const valid = selectionValid();
    document.querySelectorAll('[data-action="copy"], [data-action="cut"], [data-action="play-AB"], [data-action="export-segment"]').forEach(b=> b.disabled = !valid);
  }

  // ====== Utilitaires ======
  const fmtTime = (sec) => {
    if (!isFinite(sec)) return '00:00.000';
    const s = Math.max(0, sec);
    const m = Math.floor(s / 60);
    const r = s - m * 60;
    const rInt = Math.floor(r);
    const ms = Math.round((r - rInt) * 1000);
    const pad = (n, w=2) => String(n).padStart(w,'0');
    return `${pad(m)}:${pad(rInt)}.${pad(ms,3)}`;
  };

  const parseTime = (txt) => {
    // Formats acceptés: mm:ss.mmm, ss.mmm, mm:ss
    if (!txt) return null;
    const m = txt.match(/^(?:(\d+):)?(\d+)(?:\.(\d{1,3}))?$/);
    if (!m) return null;
    const min = parseInt(m[1]||'0',10);
    const sec = parseInt(m[2]||'0',10);
    const ms = parseInt((m[3]||'0').padEnd(3,'0'),10);
    return min*60 + sec + ms/1000;
  };

  const setStatus = (msg) => { statusEl.textContent = msg || ''; };

  function enableActions(actions){
    actions.forEach(sel=>{
      document.querySelectorAll(`[data-action="${sel}"]`).forEach(b=>b.disabled=false);
    });
  }
  function disableActions(actions){
    actions.forEach(sel=>{
      document.querySelectorAll(`[data-action="${sel}"]`).forEach(b=>b.disabled=true);
    });
  }

  // ====== Menu déroulant ======
  document.querySelectorAll('.menu-btn').forEach(btn=>{
    btn.addEventListener('click', (e)=>{
      const name = btn.dataset.menu;
      document.querySelectorAll('.menu-dropdown').forEach(dd=>{
        dd.classList.toggle('open', dd.dataset.dropdown===name && !dd.classList.contains('open'));
        if (dd.dataset.dropdown!==name) dd.classList.remove('open');
      });
    });
  });
  document.addEventListener('click', (e)=>{
    if (!e.target.closest('.menu-group')){
      document.querySelectorAll('.menu-dropdown').forEach(dd=>dd.classList.remove('open'));
    }
  });

  // ====== Gestion fichier ======
  document.querySelectorAll('[data-action="open-file"]').forEach(b=>b.addEventListener('click', ()=>fileInput.click()));
  fileInput.addEventListener('change', async (e)=>{
    const file = e.target.files?.[0];
    if (!file) return;
    setStatus('Chargement du MP3…');

    const ab = await file.arrayBuffer();
    originalMp3 = ab;
    const u8 = new Uint8Array(ab);

    // Lire ID3v2 si présent et extraire la partie audio (sans tag)
    const { tag, audioBytes, info } = readID3v2(u8);
    id3Read = tag || {};
    audioDataBytes = audioBytes || u8;
    fileInfoEl.textContent = `${file.name} • ${(file.size/1024/1024).toFixed(2)} Mo`;

    // MAJ formulaire
    fillTagForm(id3Read);

    // Activer sauvegarde métadonnées
    enableActions(['save-mp3']);

    // Décoder audio pour la forme d'onde
    await ensureAudioContext();
    try {
      const audioBuf = await audioCtx.decodeAudioData(audioDataBytes.buffer.slice(audioDataBytes.byteOffset, audioDataBytes.byteOffset + audioDataBytes.byteLength));
      buffer = audioBuf;
      drawWaveform();
      totalTimeEl.textContent = fmtTime(buffer.duration);
      enableTransport();
      setStatus('MP3 chargé.');
    } catch(err){
      console.error(err);
      setStatus('Échec du décodage audio. Essayez un autre fichier.');
    }
  });

  function enableTransport(){
    enableActions(['play','stop','play-AB']);
    document.querySelector('[data-action="pause"]').disabled = !playing;
    enableActions(['export-segment']);
  }

  async function ensureAudioContext(){
    if (!audioCtx){
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended'){
      try { await audioCtx.resume(); } catch{}
    }
  }

  // ====== Lecture / Transport ======
  function play(offset=0){
    if (!buffer) return;
    stop();
    source = audioCtx.createBufferSource();
    source.buffer = buffer;
    source.connect(audioCtx.destination);
    startOffset = offset;
    startTime = audioCtx.currentTime;
    source.start(0, offset);
    playing = true;
    document.querySelectorAll('[data-action="pause"],[data-action="stop"]').forEach(b=>b.disabled=false);

    source.onended = ()=>{
      playing = false;
      document.querySelector('[data-action="pause"]').disabled = true;
      document.querySelector('[data-action="stop"]').disabled = true;
    };
  }

  function pause(){
    if (!playing) return;
    const elapsed = audioCtx.currentTime - startTime;
    startOffset += elapsed;
    stop(false);
  }

  function stop(resetOffset=true){
    try { source?.stop?.(); } catch{}
    source = null;
    playing = false;
    if (resetOffset) startOffset = 0;
    document.querySelector('[data-action="pause"]').disabled = true;
    document.querySelector('[data-action="stop"]').disabled = true;
  }

  function currentPlaybackTime(){
    if (!playing) return startOffset;
    return startOffset + (audioCtx.currentTime - startTime);
  }

  function playAB(loop=false){
    if (A==null || B==null || !buffer) return;
    const start = Math.max(0, Math.min(A,B));
    const end = Math.min(buffer.duration, Math.max(A,B));
    if (end <= start) return;
    stop();
    source = audioCtx.createBufferSource();
    source.buffer = buffer;
    source.connect(audioCtx.destination);
    source.start(0, start, end-start);
    if (loop){
      source.loop = true;
      source.loopStart = start;
      source.loopEnd = end;
    }
    playing = true;
    document.querySelector('[data-action="pause"]').disabled = false;
    document.querySelector('[data-action="stop"]').disabled = false;
    source.onended = ()=>{ if (!loop) { playing=false; }};
  }

  // ====== Dessin forme d'onde ======
  function drawWaveform(){
    const W = waveCanvas.width;
    const H = waveCanvas.height;
    ctxWave.clearRect(0,0,W,H);

    ctxWave.fillStyle = '#0b1220';
    ctxWave.fillRect(0,0,W,H);

    if (!buffer){
      ctxWave.fillStyle = '#64748b';
      ctxWave.fillText('Chargez un MP3 pour afficher la forme d\'onde', 20, 30);
      return;
    }

    const ch = buffer.getChannelData(0);
    const samples = ch.length;
    const samplesPerPixel = Math.max(1, Math.floor(samples / (W * (1/zoom))));
    const step = samplesPerPixel;
    const mid = H/2;

    ctxWave.strokeStyle = '#22d3ee';
    ctxWave.lineWidth = 1;

    // Zoom: on dessine une fenêtre autour du temps courant si zoom>1
    const centerTime = currentPlaybackTime();
    const visibleDur = buffer.duration / zoom;
    let startTimeWin = Math.max(0, centerTime - visibleDur/2);
    let endTimeWin = Math.min(buffer.duration, startTimeWin + visibleDur);
    if (endTimeWin - startTimeWin < visibleDur) startTimeWin = Math.max(0, endTimeWin - visibleDur);

    const startSample = Math.floor(startTimeWin * buffer.sampleRate);
    const endSample = Math.min(samples, Math.floor(endTimeWin * buffer.sampleRate));
    const winSamples = endSample - startSample;
    const spp = Math.max(1, Math.floor(winSamples / W));

    ctxWave.beginPath();
    for (let x=0; x<W; x++){
      const i0 = startSample + x * spp;
      const i1 = Math.min(endSample, i0 + spp);
      let min=1e9, max=-1e9;
      for (let i=i0; i<i1; i++){
        const v = ch[i] || 0;
        if (v<min) min=v; if (v>max) max=v;
      }
      const y1 = mid + min*mid;
      const y2 = mid + max*mid;
      ctxWave.moveTo(x, y1);
      ctxWave.lineTo(x, y2);
    }
    ctxWave.stroke();

    // Grille temps
    ctxWave.strokeStyle = 'rgba(255,255,255,0.08)';
    ctxWave.lineWidth = 1;
    ctxWave.beginPath();
    const gridEvery = gridStep(visibleDur);
    for (let t = Math.ceil(startTimeWin/gridEvery)*gridEvery; t<endTimeWin; t+=gridEvery){
      const x = (t - startTimeWin) / visibleDur * W;
      ctxWave.moveTo(x,0); ctxWave.lineTo(x,H);
    }
    ctxWave.stroke();

    // Marqueurs
    markers.forEach(m=>{
      const x = (m.time - startTimeWin) / visibleDur * W;
      if (x<0 || x>W) return;
      ctxWave.strokeStyle = m.id===selectedMarkerId? '#f97316' : '#34d399';
      ctxWave.beginPath();
      ctxWave.moveTo(x,0); ctxWave.lineTo(x,H);
      ctxWave.stroke();
    });

    // Sélection A–B
    if (A!=null && B!=null){
      const s = Math.min(A,B), e = Math.max(A,B);
      const x1 = (s - startTimeWin) / visibleDur * W;
      const x2 = (e - startTimeWin) / visibleDur * W;
      ctxWave.fillStyle = 'rgba(99, 102, 241, .25)';
      ctxWave.fillRect(x1,0,x2-x1,H);
    }

    // Curseur lecture
    const tNow = currentPlaybackTime();
    const xCur = (tNow - startTimeWin) / visibleDur * W;
    ctxWave.strokeStyle = '#eab308';
    ctxWave.beginPath();
    ctxWave.moveTo(xCur,0); ctxWave.lineTo(xCur,H);
    ctxWave.stroke();

    // Temps courant
    currentTimeEl.textContent = fmtTime(tNow);

    // Redessin régulier en lecture
    if (playing){
      requestAnimationFrame(drawWaveform);
    }
  }

  function gridStep(visibleDur){
    const candidates = [0.05,0.1,0.2,0.5,1,2,5,10,15,30,60,120,300];
    for (const c of candidates){
      const count = visibleDur / c;
      if (count <= 12) return c;
    }
    return 600;
  }

  zoomEl.addEventListener('input', (e)=>{
    zoom = parseInt(zoomEl.value,10);
    drawWaveform();
  });

  // Cliquer/drag sur le canvas pour positionner le temps/les marqueurs
  let isDragging = false;
  waveCanvas.addEventListener('mousedown', (e)=>{
    if (!buffer) return;
    isDragging = true;
    const t = xToTime(e.offsetX);
    // Clic avec Alt -> définir A, Shift -> définir B, sinon déplacer le curseur
    if (e.altKey) { A = t; markerAEl.value = fmtTime(A); updateSelectionButtons(); }
    else if (e.shiftKey) { B = t; markerBEl.value = fmtTime(B); updateSelectionButtons(); }
    else { playheadTo(t); }
    drawWaveform();
  });
  waveCanvas.addEventListener('mousemove', (e)=>{
    if (!buffer || !isDragging) return;
    const t = xToTime(e.offsetX);
    if (e.altKey) { A = t; markerAEl.value = fmtTime(A); updateSelectionButtons(); }
    else if (e.shiftKey) { B = t; markerBEl.value = fmtTime(B); updateSelectionButtons(); }
    drawWaveform();
  });
  document.addEventListener('mouseup', ()=>{ isDragging=false; });

  function xToTime(x){
    const W = waveCanvas.width;
    const centerTime = currentPlaybackTime();
    const visibleDur = buffer.duration / zoom;
    const startTimeWin = Math.max(0, Math.min(buffer.duration - visibleDur, centerTime - visibleDur/2));
    const t = startTimeWin + (x / W) * visibleDur;
    return Math.max(0, Math.min(buffer.duration, t));
  }

  function playheadTo(t){
    if (!buffer) return;
    const wasPlaying = playing;
    stop();
    startOffset = Math.max(0, Math.min(buffer.duration, t));
    if (wasPlaying) play(startOffset);
  }

  // ====== Marqueurs ======
  function addMarker(t){
    const id = Math.random().toString(36).slice(2,9);
    markers.push({id, time:t});
    renderMarkerList();
    drawWaveform();
  }

  function deleteSelectedMarker(){
    if (!selectedMarkerId) return;
    markers = markers.filter(m=>m.id!==selectedMarkerId);
    selectedMarkerId = null;
    renderMarkerList();
    drawWaveform();
  }

  function renderMarkerList(){
    markerListEl.innerHTML = '';
    markers.sort((a,b)=>a.time-b.time);
    markers.forEach(m=>{
      const li = document.createElement('li');
      const left = document.createElement('span');
      left.textContent = fmtTime(m.time);
      const right = document.createElement('span');
      const go = document.createElement('button');
      go.textContent = 'Aller';
      go.addEventListener('click', ()=>playheadTo(m.time));
      const sel = document.createElement('button');
      sel.textContent = 'Sélectionner';
      sel.addEventListener('click', ()=>{ selectedMarkerId = m.id; renderMarkerList(); drawWaveform(); enableActions(['delete-selected-marker']); });
      li.append(left);
      right.append(sel, go);
      li.append(right);
      if (m.id===selectedMarkerId) li.style.background = '#fff7ed';
      markerListEl.append(li);
    });
    if (!selectedMarkerId) disableActions(['delete-selected-marker']);
  }

  // ====== Copie/Couper/Coller + Export WAV ======
  function getSelection(){
    if (!buffer || A==null || B==null) return null;
    const start = Math.max(0, Math.min(A,B));
    const end = Math.min(buffer.duration, Math.max(A,B));
    if (end <= start) return null;
    const len = end - start;
    const out = audioCtx.createBuffer(buffer.numberOfChannels, Math.floor(len * buffer.sampleRate), buffer.sampleRate);
    for (let ch=0; ch<buffer.numberOfChannels; ch++){
      const src = buffer.getChannelData(ch);
      const dst = out.getChannelData(ch);
      const s0 = Math.floor(start * buffer.sampleRate);
      const s1 = Math.floor(end * buffer.sampleRate);
      for (let i=0; i < s1-s0; i++) dst[i] = src[s0+i] || 0;
    }
    return out;
  }

  function exportWavFromBuffer(buf, filename){
    const wav = encodeWAV(buf);
    const blob = new Blob([wav], {type:'audio/wav'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  function encodeWAV(buf){
    // PCM 16-bit LE WAV
    const numCh = buf.numberOfChannels;
    const sr = buf.sampleRate;
    const len = buf.length;
    const bytesPerSample = 2;
    const blockAlign = numCh * bytesPerSample;
    const byteRate = sr * blockAlign;
    const dataSize = len * blockAlign;

    const ab = new ArrayBuffer(44 + dataSize);
    const dv = new DataView(ab);
    let p=0;
    function writeStr(s){ for (let i=0;i<s.length;i++) dv.setUint8(p++, s.charCodeAt(i)); }
    function writeU32(v){ dv.setUint32(p, v, true); p+=4; }
    function writeU16(v){ dv.setUint16(p, v, true); p+=2; }

    writeStr('RIFF');
    writeU32(36 + dataSize);
    writeStr('WAVE');
    writeStr('fmt ');
    writeU32(16); // PCM header size
    writeU16(1);  // PCM format
    writeU16(numCh);
    writeU32(sr);
    writeU32(byteRate);
    writeU16(blockAlign);
    writeU16(16); // bits per sample
    writeStr('data');
    writeU32(dataSize);

    // Interleaver
    const chans = [];
    for (let ch=0; ch<numCh; ch++) chans.push(buf.getChannelData(ch));
    for (let i=0; i<len; i++){
      for (let ch=0; ch<numCh; ch++){
        let v = Math.max(-1, Math.min(1, chans[ch][i]));
        dv.setInt16(p, (v<0? v*0x8000 : v*0x7FFF), true); p+=2;
      }
    }

    return ab;
  }

  // ====== ID3v2 lecture/écriture ======
  function readID3v2(u8){
    // Retourne { tag: {title, artist, album, year, track, comment}, audioBytes: Uint8Array, info: {...} }
    if (u8.length < 10) return { tag: {}, audioBytes: u8, info: {} };
    if (String.fromCharCode(u8[0],u8[1],u8[2]) !== 'ID3') return { tag: {}, audioBytes: u8, info: {} };

    const ver = u8[3]; // 3=v2.3, 4=v2.4
    const flags = u8[5];
    const size = syncsafeToInt(u8[6],u8[7],u8[8],u8[9]);
    let offset = 10;

    // extended header (rare)
    if (flags & 0x40){
      const extSize = (ver===4) ? syncsafeToInt(u8[offset],u8[offset+1],u8[offset+2],u8[offset+3]) :
                                  ((u8[offset]<<24)|(u8[offset+1]<<16)|(u8[offset+2]<<8)|u8[offset+3]);
      offset += 4 + extSize; // simplifié
    }

    const end = 10 + size;
    const tag = {};

    while (offset + 10 <= end){
      const id = String.fromCharCode(u8[offset],u8[offset+1],u8[offset+2],u8[offset+3]);
      const fsize = (ver===4) ? syncsafeToInt(u8[offset+4],u8[offset+5],u8[offset+6],u8[offset+7])
                              : ((u8[offset+4]<<24)|(u8[offset+5]<<16)|(u8[offset+6]<<8)|u8[offset+7]);
      const flags = (u8[offset+8]<<8)|u8[offset+9];
      offset += 10;
      if (fsize <= 0 || offset + fsize > u8.length) break;
      const frame = u8.subarray(offset, offset+fsize);
      offset += fsize;
      if (!/^[A-Z0-9]{4}$/.test(id)) break;

      if (id[0] === 'T'){ // text frame
        const { text } = decodeID3TextFrame(frame);
        if (id==='TIT2') tag.title = text;
        else if (id==='TPE1') tag.artist = text;
        else if (id==='TALB') tag.album = text;
        else if (id==='TDRC' || id==='TYER') tag.year = text;
        else if (id==='TRCK') tag.track = text;
      } else if (id==='COMM'){
        const { text } = decodeID3CommentFrame(frame);
        tag.comment = text;
      }
    }

    const audioStart = 10 + size; // sauter le tag
    const audioBytes = u8.subarray(audioStart);
    return { tag, audioBytes, info: { version: ver } };
  }

  function decodeID3TextFrame(frame){
    const enc = frame[0];
    const bytes = frame.subarray(1);
    try {
      if (enc === 0){ // ISO-8859-1
        return { text: latin1Decode(bytes) };
      } else if (enc === 1){ // UTF-16 with BOM
        // BOM 0xFFFE or 0xFEFF handled by TextDecoder
        const dec = new TextDecoder('utf-16');
        return { text: dec.decode(bytes).replace(/\x00+$/,'') };
      } else if (enc === 3){ // UTF-8
        const dec = new TextDecoder('utf-8');
        return { text: dec.decode(bytes).replace(/\x00+$/,'') };
      }
    } catch{}
    return { text: '' };
  }

  function decodeID3CommentFrame(frame){
    const enc = frame[0];
    const lang = String.fromCharCode(frame[1],frame[2],frame[3]);
    let i=4;
    // description \0 terminated, then text
    while (i<frame.length && frame[i]!==0) i++;
    i++;
    const textBytes = frame.subarray(i);
    if (enc===0){ return { text: latin1Decode(textBytes) }; }
    if (enc===1){ return { text: new TextDecoder('utf-16').decode(textBytes) }; }
    if (enc===3){ return { text: new TextDecoder('utf-8').decode(textBytes) }; }
    return { text: '' };
  }

  function latin1Decode(u8){
    let s='';
    for (let i=0;i<u8.length;i++) s += String.fromCharCode(u8[i]);
    try { return decodeURIComponent(escape(s)); } catch { return s; }
  }

  function syncsafeToInt(a,b,c,d){
    return ((a&0x7f)<<21)|((b&0x7f)<<14)|((c&0x7f)<<7)|(d&0x7f);
  }

  function intToSyncsafe(n){
    return new Uint8Array([ (n>>21)&0x7f, (n>>14)&0x7f, (n>>7)&0x7f, n&0x7f ]);
  }

  function buildID3v23Tag(fields){
    // fields: { title, artist, album, year, track, comment }
    // On écrit un tag v2.3 avec frames texte en UTF-16 (enc=1, BOM)
    const frames = [];
    function addTextFrame(id, text){
      if (text==null || text==='') return;
      const enc = 1; // UTF-16 with BOM
      const encByte = new Uint8Array([enc]);
      const bom = new Uint8Array([0xFF,0xFE]); // UTF-16LE BOM
      const utf16 = new TextEncoder('utf-16le').encode(text);
      const payload = concatU8(encByte, bom, utf16);
      const head = new Uint8Array(10);
      head[0]=id.charCodeAt(0); head[1]=id.charCodeAt(1); head[2]=id.charCodeAt(2); head[3]=id.charCodeAt(3);
      const size = payload.length;
      head[4]=(size>>>24)&255; head[5]=(size>>>16)&255; head[6]=(size>>>8)&255; head[7]=size&255; // v2.3: non-syncsafe
      head[8]=0; head[9]=0;
      frames.push(concatU8(head, payload));
    }

    function addComm(text){
      if (!text) return;
      const enc = 1; // UTF-16 with BOM
      const encByte = new Uint8Array([enc]);
      const lang = new Uint8Array([0x65,0x6E,0x67]); // 'eng'
      const bom = new Uint8Array([0xFF,0xFE]);
      const desc = new Uint8Array([0x00,0x00]); // empty desc (UTF-16LE null)
      const utf16 = new TextEncoder('utf-16le').encode(text);
      const payload = concatU8(encByte, lang, bom, desc, utf16);
      const head = new Uint8Array(10);
      head.set([0x43,0x4F,0x4D,0x4D]); // 'COMM'
      const size = payload.length;
      head[4]=(size>>>24)&255; head[5]=(size>>>16)&255; head[6]=(size>>>8)&255; head[7]=size&255;
      frames.push(concatU8(head, payload));
    }

    addTextFrame('TIT2', fields.title);
    addTextFrame('TPE1', fields.artist);
    addTextFrame('TALB', fields.album);
    addTextFrame('TYER', fields.year || ''); // v2.3 utilise TYER
    addTextFrame('TRCK', fields.track);
    addComm(fields.comment);

    const framesBlob = concatU8(...frames);
    const header = new Uint8Array(10);
    header[0]=0x49; header[1]=0x44; header[2]=0x33; // 'ID3'
    header[3]=0x03; // v2.3
    header[4]=0x00; // revision
    header[5]=0x00; // flags
    const sizeBytes = intToSyncsafe(framesBlob.length);
    header.set(sizeBytes, 6);

    return concatU8(header, framesBlob);
  }

  function concatU8(...parts){
    const total = parts.reduce((s,p)=> s + p.length, 0);
    const out = new Uint8Array(total);
    let o=0; for (const p of parts){ out.set(p,o); o+=p.length; }
    return out;
  }

  function saveMp3WithTags(){
    if (!audioDataBytes) return;
    const fields = Object.fromEntries(new FormData(tagForm).entries());
    const id3 = buildID3v23Tag(fields);
    const out = concatU8(id3, audioDataBytes);
    const blob = new Blob([out], {type:'audio/mpeg'});
    const a = document.createElement('a');
    const safeTitle = (fields.title||'piste').replace(/[^\w\-\u00C0-\u024F]+/g,'_').slice(0,64);
    a.href = URL.createObjectURL(blob);
    a.download = `${safeTitle||'piste'}.mp3`;
    a.click();
    URL.revokeObjectURL(a.href);
    setStatus('MP3 enregistré avec nouvelles métadonnées.');
  }

  function fillTagForm(tag){
    tagForm.elements['title'].value = tag.title || '';
    tagForm.elements['artist'].value = tag.artist || '';
    tagForm.elements['album'].value = tag.album || '';
    tagForm.elements['year'].value = tag.year || '';
    tagForm.elements['track'].value = tag.track || '';
    tagForm.elements['comment'].value = tag.comment || '';
  }

  // ====== Piste 2 rendu simple ======
  function renderTrack2(){
    const W = track2Canvas.width;
    const H = track2Canvas.height;
    ctxT2.clearRect(0,0,W,H);
    ctxT2.fillStyle = '#0b1220';
    ctxT2.fillRect(0,0,W,H);

    let totalDur = track2.reduce((s,seg)=> s + seg.buffer.duration, 0);
    if (totalDur<=0){
      ctxT2.fillStyle = '#94a3b8';
      ctxT2.fillText('Piste 2 vide. Utilisez « Coller dans Piste 2 ».', 20, 24);
      return;
    }

    let x=0;
    for (const seg of track2){
      const w = Math.max(1, Math.floor((seg.buffer.duration / totalDur) * W));
      ctxT2.fillStyle = '#22c55e';
      ctxT2.fillRect(x, 20, w-2, H-40);
      ctxT2.fillStyle = '#e2e8f0';
      ctxT2.fillText(fmtTime(seg.buffer.duration), x+6, H/2);
      x += w;
    }
  }

  async function playTrack2(){
    if (track2.length===0) return;
    await ensureAudioContext();
    stop();

    // Concaténer via OfflineAudioContext pour lecture fluide
    const sr = buffer ? buffer.sampleRate : 44100;
    const totalDur = track2.reduce((s,seg)=> s + seg.buffer.duration, 0);
    const length = Math.floor(totalDur * sr);
    const off = new OfflineAudioContext(2, Math.max(1,length), sr);
    let cursor = 0;
    for (const seg of track2){
      const src = off.createBufferSource();
      src.buffer = seg.buffer;
      src.connect(off.destination);
      src.start(cursor);
      cursor += seg.buffer.duration;
    }
    const mix = await off.startRendering();

    source = audioCtx.createBufferSource();
    source.buffer = mix;
    source.connect(audioCtx.destination);
    source.start(0);
    playing = true;
  }

  function clearTrack2(){
    track2 = [];
    renderTrack2();
    disableActions(['export-track2','clear-track2']);
  }

  // ====== Écouteurs menu/actions ======
  document.querySelectorAll('[data-action="play"]').forEach(b=>b.addEventListener('click', ()=> play(currentPlaybackTime())));
  document.querySelectorAll('[data-action="pause"]').forEach(b=>b.addEventListener('click', ()=> { pause(); drawWaveform(); }));
  document.querySelectorAll('[data-action="stop"]').forEach(b=>b.addEventListener('click', ()=> { stop(); drawWaveform(); }));
  document.querySelectorAll('[data-action="back-1s"]').forEach(b=>b.addEventListener('click', ()=> { playheadTo(Math.max(0, currentPlaybackTime()-1)); drawWaveform(); }));
  document.querySelectorAll('[data-action="play-AB"]').forEach(b=>b.addEventListener('click', ()=> playAB(loopABEl.checked)));
  document.querySelectorAll('[data-action="add-marker"]').forEach(b=>b.addEventListener('click', ()=> { addMarker(currentPlaybackTime()); }));
  document.querySelectorAll('[data-action="delete-selected-marker"]').forEach(b=>b.addEventListener('click', ()=> deleteSelectedMarker()));
  document.querySelectorAll('[data-action="set-A"]').forEach(b=>b.addEventListener('click', ()=> { A=currentPlaybackTime(); markerAEl.value=fmtTime(A); updateSelectionButtons(); drawWaveform(); }));
  document.querySelectorAll('[data-action="set-B"]').forEach(b=>b.addEventListener('click', ()=> { B=currentPlaybackTime(); markerBEl.value=fmtTime(B); updateSelectionButtons(); drawWaveform(); }));
  document.querySelectorAll('[data-action="clear-AB"]').forEach(b=>b.addEventListener('click', ()=> { A=B=null; markerAEl.value=''; markerBEl.value=''; updateSelectionButtons(); drawWaveform(); }));

  document.querySelectorAll('[data-action="apply-AB"]').forEach(b=>b.addEventListener('click', ()=> {
    const a = parseTime(markerAEl.value); const b = parseTime(markerBEl.value);
    if (a!=null) A=a; if (b!=null) B=b; updateSelectionButtons(); drawWaveform();
  }));

  document.querySelectorAll('[data-action="copy"]').forEach(b=>b.addEventListener('click', ()=> {
    const seg = getSelection();
    if (!seg){ setStatus('Sélection A–B invalide.'); return; }
    // mettre dans un presse-papiers interne
    window.__audioClipboard = seg;
    enableActions(['paste-to-track2']);
    setStatus('Segment copié.');
  }));

  document.querySelectorAll('[data-action="cut"]').forEach(b=>b.addEventListener('click', ()=> {
    const seg = getSelection();
    if (!seg){ setStatus('Sélection A–B invalide.'); return; }
    window.__audioClipboard = seg;
    enableActions(['paste-to-track2']);
    setStatus('Segment copié (couper ne modifie pas la piste originale dans cette version).');
  }));

  document.querySelectorAll('[data-action="paste-to-track2"]').forEach(b=>b.addEventListener('click', ()=> {
    const seg = window.__audioClipboard;
    if (!seg){ setStatus('Rien à coller.'); return; }
    track2.push({ buffer: seg });
    renderTrack2();
    enableActions(['export-track2','clear-track2','play-track2']);
  }));
  document.querySelectorAll('[data-action="play-track2"]').forEach(b=>b.addEventListener('click', ()=> { playTrack2(); }));
  document.querySelectorAll('[data-action="clear-track2"]').forEach(b=>b.addEventListener('click', ()=> { clearTrack2(); }));

  document.querySelectorAll('[data-action="export-segment"]').forEach(b=>b.addEventListener('click', ()=>{
    const seg = getSelection();
    if (!seg){ setStatus('Sélection A–B invalide.'); return; }
    exportWavFromBuffer(seg, 'segment.wav');
  }));

  document.querySelectorAll('[data-action="export-track2"]').forEach(b=>b.addEventListener('click', async ()=>{
    if (track2.length===0) return;
    const sr = buffer ? buffer.sampleRate : 44100;
    const totalDur = track2.reduce((s,seg)=> s + seg.buffer.duration, 0);
    const length = Math.floor(totalDur * sr);
    const off = new OfflineAudioContext(2, Math.max(1,length), sr);
    let cursor = 0;
    for (const seg of track2){
      const src = off.createBufferSource();
      src.buffer = seg.buffer;
      src.connect(off.destination);
      src.start(cursor);
      cursor += seg.buffer.duration;
    }
    const mix = await off.startRendering();
    exportWavFromBuffer(mix, 'piste2.wav');
  }));

  document.querySelectorAll('[data-action="save-mp3"]').forEach(b=>b.addEventListener('click', ()=> saveMp3WithTags()));

  // ====== Raccourcis clavier ======
  document.addEventListener('keydown', (e)=>{
    if (e.target && (e.target.tagName==='INPUT' || e.target.tagName==='TEXTAREA')) return;
    if (e.key===' '){ e.preventDefault(); if (playing) pause(); else play(currentPlaybackTime()); drawWaveform(); }
    if (e.key==='m' || e.key==='M'){ addMarker(currentPlaybackTime()); }
  });

})();
