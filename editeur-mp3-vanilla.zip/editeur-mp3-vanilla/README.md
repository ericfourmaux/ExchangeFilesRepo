# Éditeur MP3 (Vanilla JavaScript)

Application 100% client (HTML/CSS/JS) pour :

- Lire un fichier **.mp3**, afficher sa **forme d'onde** (Canvas) avec **zoom**
- Placer des **marqueurs** et définir une **sélection A–B**
- Faire **lecture / pause / stop** et **lecture A–B** (avec option boucle)
- **Copier/Couper** la sélection et **coller** dans une **Piste 2** (assemblage de segments)
- **Exporter** un **segment** ou la **Piste 2** en **WAV** (PCM 16‑bit)
- **Lire** les métadonnées **ID3v2.3/v2.4** courantes et **écrire** de nouvelles métadonnées **ID3v2.3** (UTF‑16) dans le MP3

## Démarrage

1. Ouvrez `index.html` dans un navigateur moderne (Chrome, Edge, Firefox). 
   - Sur certains navigateurs, il peut être nécessaire d'autoriser l'audio à démarrer après une interaction utilisateur (cliquez sur « Lecture » si besoin).
2. Menu **Fichier → Ouvrir** pour choisir un .mp3.
3. Lisez / zoomez, placez les marqueurs (Alt+clic pour **A**, Shift+clic pour **B**), utilisez lecture **A–B**.
4. Menu **Édition** pour copier/coller et **Fichier** pour exporter en **WAV** ou **Enregistrer MP3 + métadonnées**.

## Détails techniques

- **Audio** : Web Audio API (AudioContext, OfflineAudioContext) pour décoder, lire, concaténer et exporter en **WAV**.
- **Forme d'onde** : rendu min/max par colonne, avec fenêtre glissante en fonction du **zoom**.
- **Tags ID3** :
  - Lecture : ID3v2.3 et v2.4 (TIT2, TPE1, TALB, TDRC/TYER, TRCK, COMM)
  - Écriture : ID3v2.3 **UTF‑16** (frames TIT2, TPE1, TALB, TYER, TRCK, COMM) **sans image** (pas de frame APIC dans cette version).
  - Sauvegarde MP3 = **nouveau tag ID3v2.3** + **flux audio d'origine** (tag existant retiré).
- **Export segments** : en **WAV** sans perte (PCM 16-bit). L'export en **MP3** nécessiterait un encodeur supplémentaire (ex. LAME via WebAssembly). 

## Raccourcis

- **Espace** : Lecture/Pause
- **M** : Ajouter un marqueur
- **Alt+clic** sur forme d'onde : définir **A**
- **Shift+clic** sur forme d'onde : définir **B**

## Limitations connues

- Pas d'encodage en MP3 pour les segments/export Piste 2 (WAV uniquement).
- Les images d'album (frame **APIC**) ne sont pas encore prises en charge.
- Les tags exotiques/avancés (chapitres, synchronisation, etc.) ne sont pas modifiés/écrits.
- Le **couper** n'altère pas la piste d'origine (la version actuelle copie la sélection). 

## Compatibilité

Testé sur Chrome 122+, Edge 122+, Firefox 123+. Safari récent devrait fonctionner pour la plupart des fonctions, mais le décodage MP3/OfflineAudioContext peut varier selon les versions.
