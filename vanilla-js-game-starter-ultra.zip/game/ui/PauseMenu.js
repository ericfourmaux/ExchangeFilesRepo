
export class PauseMenu { constructor(scene){ this.scene=scene; this.visible=false; }
  render(ctx){ if(!this.visible) return; const W=ctx.canvas.width, H=ctx.canvas.height; ctx.save(); ctx.fillStyle='rgba(0,0,0,.6)'; ctx.fillRect(0,0,W,H); ctx.fillStyle='#fff'; ctx.font='20px sans-serif'; ctx.fillText('PAUSE', W/2-30, H/2-20); ctx.font='12px sans-serif'; ctx.fillText('Appuyez sur Échap pour reprendre', W/2-110, H/2+4); ctx.restore(); }
}
