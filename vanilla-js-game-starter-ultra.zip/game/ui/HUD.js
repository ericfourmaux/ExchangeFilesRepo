
export class HUD { constructor(scene){ this.scene=scene; this.visible=true; }
  render(ctx){ if(!this.visible) return; const p=this.scene.player; ctx.save(); ctx.fillStyle='rgba(0,0,0,.5)'; ctx.fillRect(8,8,440,78); ctx.fillStyle='#fff'; ctx.font='12px sans-serif'; ctx.fillText(`Mode: ${this.scene.mode}`, 16, 24); ctx.fillText(`Score: ${this.scene.score}  x${this.scene.multiplier.toFixed(1)}`, 120, 24); ctx.fillText(`Vies: ${this.scene.lives}`, 260, 24); ctx.fillText(`Objets: ${this.scene.objects.length}`, 16, 40); if(p) ctx.fillText(`Player: (${p.pos.x|0}, ${p.pos.y|0}) v=(${p.vel.x|0}, ${p.vel.y|0}) HP=${p.hp}`, 16, 56); ctx.restore(); }
}
