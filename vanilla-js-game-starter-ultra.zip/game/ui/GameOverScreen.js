
export class GameOverScreen { constructor(scene){ this.scene=scene; this.visible=false; this._alpha=0; }
  show(){ this.visible=true; this._alpha=0; }
  render(ctx){ if(!this.visible) return; this._alpha=Math.min(1,this._alpha+0.02); const W=ctx.canvas.width, H=ctx.canvas.height; ctx.save(); ctx.fillStyle=`rgba(0,0,0,${0.6*this._alpha})`; ctx.fillRect(0,0,W,H); ctx.fillStyle=`rgba(255,255,255,${this._alpha})`; ctx.font='22px sans-serif'; ctx.fillText('GAME OVER', W/2-60, H/2-20); ctx.font='14px sans-serif'; ctx.fillText(`Score final: ${this.scene.score}`, W/2-70, H/2+6); ctx.fillText('Appuyez sur Entrée pour recommencer', W/2-130, H/2+26); ctx.restore(); }
}
