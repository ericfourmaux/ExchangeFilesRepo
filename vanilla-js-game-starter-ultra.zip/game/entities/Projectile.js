
import { GameObject } from '../../engine/world/GameObject.js';
import { AABBCollider } from '../../engine/collision/Colliders.js';

export class Projectile extends GameObject { constructor(){ super(-9999,-9999,6,6); this._pooled=true; this.tag='projectile'; this.gravity=0; this.damage=1; this.r=3; this.color='#ffcc33'; this.collider=new AABBCollider(this.size.w,this.size.h).attach(this); this.collider.isTrigger=true; this.alive=false; }
  reset(x,y,vx,vy,{life=1.0, radius=3, color='#ffcc33', damage=1}={}){ this.pos.x=x; this.pos.y=y; this.vel.x=vx; this.vel.y=vy; this.life=life; this.r=radius; this.size.w=radius*2; this.size.h=radius*2; this.color=color; this.damage=damage; this.alive=true; }
  update(dt,scene){ if(!this.alive) return; this.pos.x+=this.vel.x*dt; this.pos.y+=this.vel.y*dt; this.life-=dt; if(this.life<=0) this.alive=false; }
  onTrigger(other){ if(!this.alive) return; if(other.tag==='enemy'){ other.hurt?.(this.damage); this.alive=false; } else if(other.tag!=='player'){ this.alive=false; } }
  render(ctx,camera){ if(!this.alive) return; const p=camera.worldToScreen(this.pos.x,this.pos.y); ctx.fillStyle=this.color; ctx.beginPath(); ctx.arc((p.x+this.r)|0,(p.y+this.r)|0,this.r,0,Math.PI*2); ctx.fill(); }
}
