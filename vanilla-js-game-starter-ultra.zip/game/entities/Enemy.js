
import { GameObject } from '../../engine/world/GameObject.js';
import { Sprite } from '../../engine/graphics/Sprite.js';
import { AABBCollider } from '../../engine/collision/Colliders.js';

function norm(x,y){ const l=Math.hypot(x,y)||1; return { x:x/l, y:y/l }; }

export class Enemy extends GameObject {
  constructor(x,y,img,{state='patrol', shoot=null}={}){ super(x,y,24,24); this.tag='enemy'; this.sprite=new Sprite(img,24,24); this.collider=new AABBCollider(22,22).attach(this); this.collider.offset.set?.(1,1);
    this.hp=3; this.state=state; this._t=0; this.sight=240; this.speed=80; this.attackRange=80; this._shootCfg=shoot; this._shootTimer=0; this._spiralAngle=0;
    this.patrol={ left:x-80, right:x+80, speed:this.speed };
  }
  onDeath(scene){ scene.particles.explosion(this.pos.x+this.size.w/2, this.pos.y+this.size.h/2, { color:'#ff9955', count:28, speed:200 }); scene.addScore?.(100); scene.game.sounds.play('explode',{volume:0.2}); }
  hurt(d=1){ this.hp-=d; if(this.hp<=0){ this.alive=false; } }
  _shootAt(scene, dx,dy, {count=1,spreadDeg=0,speed=240,color='#ff6b6b'}={}){
    const a0 = Math.atan2(dy,dx);
    if(count<=1){ const vx=Math.cos(a0)*speed, vy=Math.sin(a0)*speed; scene.spawnBullet(this.pos.x+12,this.pos.y+12,vx,vy,{color}); return; }
    const spread = (spreadDeg*Math.PI/180);
    const start = a0 - spread/2;
    for(let i=0;i<count;i++){
      const a = start + (spread*(i/(count-1)));
      const vx = Math.cos(a)*speed, vy=Math.sin(a)*speed;
      scene.spawnBullet(this.pos.x+12,this.pos.y+12,vx,vy,{color});
    }
  }
  _doShooting(scene, player, dt){ if(!this._shootCfg) return; this._shootTimer -= dt; if(this._shootTimer>0) return; const cfg=this._shootCfg; this._shootTimer = cfg.interval || 1.0;
    if(cfg.pattern==='cone'){ const dir=norm(player.pos.x-this.pos.x, player.pos.y-this.pos.y); this._shootAt(scene, dir.x, dir.y, cfg); scene.game.sounds.play('enemy_shoot',{volume:0.12}); }
    else if(cfg.pattern==='spiral'){ const step=(cfg.stepDeg||25)*(Math.PI/180); this._spiralAngle += step; const vx=Math.cos(this._spiralAngle), vy=Math.sin(this._spiralAngle); this._shootAt(scene, vx, vy, {count:1, speed: cfg.speed||200, color: cfg.color||'#66ddff'}); scene.game.sounds.play('enemy_shoot',{volume:0.12}); }
  }
  update(dt, scene){ const player=scene.player; this._t+=dt; if(!player){ super.update(dt,scene); return; }
    const dx=player.pos.x-this.pos.x, dy=player.pos.y-this.pos.y, dist=Math.hypot(dx,dy);
    // FSM configurable
    switch(this.state){
      case 'patrol':
        if(this.pos.x<this.patrol.left) this.vel.x=Math.abs(this.patrol.speed);
        if(this.pos.x>this.patrol.right) this.vel.x=-Math.abs(this.patrol.speed);
        if(dist<this.sight) this.state='chase';
        break;
      case 'chase':
        this.vel.x = (dx<0? -1:1)*this.speed; if(dist<this.attackRange) this.state='attack'; if(dist>this.sight*1.3) this.state='patrol';
        break;
      case 'attack':
        this.vel.x *= 0.9; if(dist>this.attackRange*1.6) this.state='chase'; break;
      default: break;
    }
    this._doShooting(scene, player, dt);
    this.flipX = this.vel.x < 0; super.update(dt,scene);
  }
}
