
import { GameObject } from '../../engine/world/GameObject.js';
import { Sprite } from '../../engine/graphics/Sprite.js';
import { Animation } from '../../engine/graphics/Animation.js';
import { AABBCollider } from '../../engine/collision/Colliders.js';

function norm(x,y){ const l=Math.hypot(x,y)||1; return { x:x/l, y:y/l }; }

export class Player extends GameObject {
  constructor(x,y,img,options={}){ super(x,y,24,24); this.tag='player'; this.movement=options.movement||'platformer'; this.gravity=(options.gravity??this.gravity); this.primaryMode=options.primary||'horiz';
    this.speed=260; this.speedFree=260; this.jumpForce=-460; this.coyoteTimeMax=0.12; this.coyoteTime=0; this.jumpBufferMax=0.12; this.jumpBuffer=0; this.jumping=false; this.jumpHoldMax=0.16; this.jumpHoldTime=0; this.jumpHoldAccel=-900;
    this.fireCooldown=0.18; this._cd=0; this.sprite=new Sprite(img,24,24); this.animIdle=new Animation([0,1,2,3],6,true); this.animRun=new Animation([4,5,6,7],10,true); this.animJump=new Animation([8],1,false); this.animation=this.animIdle; this.collider=new AABBCollider(20,22).attach(this); this.collider.offset.x=2; this.collider.offset.y=2; this._scene=null; this.hp=3; this.score=0;
  }
  addScore(v){ this.score=(this.score||0)+v; }
  worldMouse(scene){ const m=scene.game.input.mouse; return { x: scene.camera.pos.x + m.x, y: scene.camera.pos.y + m.y }; }
  aimDirection(scene){ if(this.primaryMode==='horiz') return { x:this.flipX?-1:1, y:0 }; if(this.primaryMode==='up') return { x:0, y:-1 }; const wm=this.worldMouse(scene); const cx=this.pos.x+this.size.w/2, cy=this.pos.y+this.size.h/2; return norm(wm.x-cx, wm.y-cy); }
  handleInputPlatformer(input,scene,dt){ let moving=false; const L=input.isDown('ArrowLeft')||input.isDown('KeyQ'); const R=input.isDown('ArrowRight')||input.isDown('KeyD'); if(L){ this.vel.x=-this.speed; this.flipX=true; moving=true;} else if(R){ this.vel.x=this.speed; this.flipX=false; moving=true;} else { this.vel.x*=this.friction; if(Math.abs(this.vel.x)<5) this.vel.x=0; }
    if(!this.grounded) this.coyoteTime=Math.max(0,this.coyoteTime-dt); const jp=input.pressed('Space')||input.pressed('KeyW')||input.pressed('KeyZ')||input.pressed('ArrowUp'); if(jp) this.jumpBuffer=this.jumpBufferMax; if(this.jumpBuffer>0 && (this.grounded||this.coyoteTime>0)){ this.vel.y=this.jumpForce; this.jumping=true; this.jumpHoldTime=0; this.grounded=false; this.coyoteTime=0; this.jumpBuffer=0; scene.game.sounds.play('jump',{volume:0.12}); }
    const jh=input.isDown('Space')||input.isDown('KeyW')||input.isDown('KeyZ')||input.isDown('ArrowUp'); if(this.jumping && jh && this.jumpHoldTime<this.jumpHoldMax){ this.vel.y+=this.jumpHoldAccel*dt; this.jumpHoldTime+=dt;} else { this.jumping=false; }
    this.jumpBuffer=Math.max(0,this.jumpBuffer-dt);
    const prim=input.pressed('KeyF') || (input.mouse.pressed && input.mouse.button===0); if(prim && this._cd<=0){ this.shootPrimary(scene); this._cd=this.fireCooldown; }
    const burst=input.pressed('KeyR') || (input.mouse.pressed && input.mouse.button===2); if(burst && scene.startBurst) scene.startBurst(this.aimDirection(scene));
    if(!this.grounded) this.animation=this.animJump; else if(moving) this.animation=this.animRun; else this.animation=this.animIdle;
  }
  handleInputFree(input,scene,dt){ const L=input.isDown('ArrowLeft')||input.isDown('KeyQ')||input.isDown('KeyA'); const R=input.isDown('ArrowRight')||input.isDown('KeyD'); const U=input.isDown('ArrowUp')||input.isDown('KeyW')||input.isDown('KeyZ'); const D=input.isDown('ArrowDown')||input.isDown('KeyS'); let dx=(R?1:0)-(L?1:0), dy=(D?1:0)-(U?1:0); const d=norm(dx,dy); this.vel.x=d.x*this.speedFree; this.vel.y=d.y*this.speedFree; this.flipX=this.vel.x<0; const prim=input.pressed('KeyF') || (input.mouse.pressed && input.mouse.button===0); if(prim && this._cd<=0){ this.shootPrimary(scene); this._cd=this.fireCooldown; } const burst=input.pressed('KeyR') || (input.mouse.pressed && input.mouse.button===2); if(burst && scene.startBurst) scene.startBurst(this.aimDirection(scene)); this.animation=(Math.abs(this.vel.x)+Math.abs(this.vel.y)>1)?this.animRun:this.animIdle; }
  shootPrimary(scene){ let dir=this.aimDirection(scene); if(this.primaryMode==='up') dir={x:0,y:-1}; if(this.primaryMode==='horiz') dir={x:this.flipX?-1:1,y:0}; const muzzle={ x:this.pos.x+(this.flipX?4:this.size.w-4), y:this.pos.y+this.size.h/2 }; const speed=520; scene.spawnBullet(muzzle.x,muzzle.y,dir.x*speed,dir.y*speed,{color:'#ffcc33',life:1.0,radius:3,damage:1}); scene.game.sounds.play('shoot',{volume:0.15}); }
  update(dt,scene){ this._scene=scene; this._cd=Math.max(0,this._cd-dt); if(this.movement==='platformer') this.handleInputPlatformer(scene.game.input,scene,dt); else this.handleInputFree(scene.game.input,scene,dt); if(this.movement==='platformer' && !this.grounded) this.vel.y+=this.gravity*dt; this.pos.x+=this.vel.x*dt; this.pos.y+=this.vel.y*dt; this.animation?.update(dt); }
  onCollision(other,info){ if(info.normal.y===-1){ this.grounded=true; this.jumping=false; this.jumpHoldTime=0; this.vel.y=0; this.coyoteTime=this.coyoteTimeMax; } }
}
