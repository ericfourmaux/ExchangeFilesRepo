
import { Camera } from '../engine/graphics/Camera.js';
import { ParallaxLayer } from '../engine/graphics/ParallaxLayer.js';
import { CollisionSystem } from '../engine/collision/CollisionSystem.js';
import { TileMap } from '../engine/world/TileMap.js';
import { Player } from './entities/Player.js';
import { Enemy } from './entities/Enemy.js';
import { Pickup } from './entities/Pickup.js';
import { TiledLoader } from '../engine/assets/TiledLoader.js';
import { Pool } from '../engine/utils/Pool.js';
import { Projectile } from './entities/Projectile.js';
import { HUD } from './ui/HUD.js';
import { PauseMenu } from './ui/PauseMenu.js';
import { GameOverScreen } from './ui/GameOverScreen.js';
import { PolygonCollider } from '../engine/collision/Colliders.js';
import { ParticleSystem } from '../engine/particles/ParticleSystem.js';

const MODE_CONFIG = {
  platformer: { gravity: 900, movement: 'platformer', primary: 'horiz', axes: {x:true,y:true} },
  runngun:    { gravity: 900, movement: 'platformer', primary: 'mouse', axes: {x:true,y:true} },
  shmup:      { gravity: 0,   movement: 'free',       primary: 'up',    axes: {x:true,y:true}, scroll: { x:0, y:-60 } },
  topdown:    { gravity: 0,   movement: 'free',       primary: 'mouse', axes: {x:true,y:true}, scroll: null },
  topdown_h:  { gravity: 0,   movement: 'free',       primary: 'mouse', axes: {x:true,y:true}, scroll: { x:60, y:0 } },
  topdown_d:  { gravity: 0,   movement: 'free',       primary: 'mouse', axes: {x:true,y:true}, scroll: { x:42, y:-42 } }
};

export class MainScene {
  constructor(game, options = {}){
    this.game = game; this.objects = []; this.collision = new CollisionSystem(64); this.camera = new Camera(game.canvas.width, game.canvas.height);
    this.parallax = [ new ParallaxLayer(this.game.loader.image('bg1'),0.2), new ParallaxLayer(this.game.loader.image('bg2'),0.4), new ParallaxLayer(this.game.loader.image('bg3'),0.7) ];
    this.mode = (options.mode || 'platformer'); this.cfg = MODE_CONFIG[this.mode] || MODE_CONFIG.platformer;
    this._tiledUrl = options.tiledUrl || (this.mode==='shmup'?'assets/level_shmup.json':'assets/level1.json'); this._tiledJson = options.tiledJson || null; this.ready=false;
    this.projectilePool = new Pool(()=> new Projectile());
    this.hud = new HUD(this); this.pauseMenu = new PauseMenu(this); this.gameOver = new GameOverScreen(this);
    this.score=0; this.multiplier=1.0; this.multTimer=0; this.multDecay=0.8; this.lives=3; this.paused=false; this.over=false;
    this.particles = new ParticleSystem();
    this._burst=null; this._waves=null; this._wavesClock=0; this._waveIndex=0; this._spawnCooldown=0; this._staticPolys=[];
    this._init();
  }

  async _init(){
    let tilemap, spawns; const tl = new TiledLoader(this.game.loader);
    if(this._tiledUrl) ({tilemap, spawns} = await tl.loadFromURL(this._tiledUrl)); else if(this._tiledJson) ({tilemap, spawns} = await tl.loadFromObject(this._tiledJson));
    else { const T=32,W=50,H=15; const tiles=Array.from({length:H},(_,y)=>Array.from({length:W},(_,x)=>(y===H-1||(y===H-5&&x%7===0))?2:-1)); tilemap=new TileMap(tiles,T,this.game.loader.image('tiles'),new Set([2])); spawns={ player:{x:100,y:100}, enemies:[], pickups:[], polygons:[] }; }
    this.tilemap = tilemap; const worldW=this.tilemap.w*this.tilemap.tileSize; const worldH=this.tilemap.h*this.tilemap.tileSize;

    // Static polygon colliders (pentes/obstacles)
    this._staticPolys = (spawns.polygons||[]).map(poly=>({
      pos:{x:poly.x,y:poly.y}, vel:{x:0,y:0},
      getAABB: ()=>{ const xs=poly.points.map(p=>p.x+poly.x), ys=poly.points.map(p=>p.y+poly.y); const minX=Math.min(...xs), maxX=Math.max(...xs), minY=Math.min(...ys), maxY=Math.max(...ys); return { x:minX, y:minY, w:maxX-minX, h:maxY-minY }; },
      collider: new PolygonCollider(poly.points).attach({ pos:{ x: poly.x, y: poly.y } })
    }));

    const pSpawn = spawns.player || { x:100, y:100 };
    this.player = new Player(pSpawn.x, pSpawn.y, this.game.loader.image('player'), { movement:this.cfg.movement, gravity:this.cfg.gravity, primary:this.cfg.primary });
    this.player.addScore = (v)=>{ this.addScore(v); };
    this.objects.push(this.player);

    for(const e of (spawns.enemies||[])) this.objects.push(new Enemy(e.x,e.y,this.game.loader.image('enemy')));
    for(const p of (spawns.pickups||[])) this.objects.push(new Pickup(p.x,p.y,this.game.loader.image('pickup')));

    this.camera.follow(this.player.pos); this.camera.setBounds(0,0,worldW,worldH); this.camera.setAxes(this.cfg.axes.x,this.cfg.axes.y);

    // Load waves.json (optional)
    try { const res = await fetch('assets/waves.json'); if(res.ok){ this._waves = await res.json(); this._wavesClock=0; this._waveIndex=0; } } catch(e){}

    this.ready=true;
  }

  addScore(v){ this.score+=Math.floor(v*this.multiplier); this.multiplier=Math.min(5, this.multiplier+0.1); this.multTimer=2.0; }

  addObject(o){ this.objects.push(o); }
  spawnBullet(x,y,vx,vy,opts={}){ const obj=this.projectilePool.acquire(); obj.reset(x,y,vx,vy,opts); this.addObject(obj); }
  startBurst(dir){ this._burst={ pending:3, timer:0, interval:0.05, dir:{x:dir.x,y:dir.y}, speed:520 }; }

  _processBurst(dt){ if(!this._burst || this._burst.pending<=0) return; this._burst.timer -= dt; if(this._burst.timer<=0){ const s=Math.hypot(this._burst.dir.x,this._burst.dir.y)||1; const nx=this._burst.dir.x/s, ny=this._burst.dir.y/s; const spread=(Math.random()-0.5)*0.12; const rx=nx*Math.cos(spread)-ny*Math.sin(spread), ry=nx*Math.sin(spread)+ny*Math.cos(spread); const mzx=this.player.pos.x+this.player.size.w/2, mzy=this.player.pos.y+this.player.size.h/2; this.spawnBullet(mzx,mzy,rx*this._burst.speed,ry*this._burst.speed,{color:'#ffa94d',life:0.9,radius:3}); this._burst.pending--; this._burst.timer=this._burst.interval; this.game.sounds.play('burst',{volume:0.15}); } }

  _autoScroll(dt){ const sc=this.cfg.scroll; if(!sc) return; this.camera.pos.x += (sc.x||0)*dt; this.camera.pos.y += (sc.y||0)*dt; // keep player in screen
    const pxMin=this.camera.pos.x+8, pyMin=this.camera.pos.y+8; const pxMax=this.camera.pos.x+this.camera.viewW-8-this.player.size.w; const pyMax=this.camera.pos.y+this.camera.viewH-8-this.player.size.h; this.player.pos.x=Math.max(pxMin,Math.min(this.player.pos.x,pxMax)); this.player.pos.y=Math.max(pyMin,Math.min(this.player.pos.y,pyMax)); }

  _evalSpawnCoord(val, axis){ if(typeof val==='number') return val; if(val==='top') return this.camera.pos.y-20; if(val==='bottom') return this.camera.pos.y+this.camera.viewH+20; if(val==='left') return this.camera.pos.x-20; if(val==='right') return this.camera.pos.x+this.camera.viewW+20; if(val==='center') return axis==='x'? (this.camera.pos.x+this.camera.viewW/2) : (this.camera.pos.y+this.camera.viewH/2); const m=/range\(([-\d.]+),([-\d.]+)\)/.exec(val||''); if(m){ const a=parseFloat(m[1]), b=parseFloat(m[2]); return a + Math.random()*(b-a); } return (axis==='x'? this.camera.pos.x+this.camera.viewW/2 : this.camera.pos.y); }

  _updateWaves(dt){ if(!this._waves) return; this._wavesClock += dt; const waves=this._waves.waves||[]; while(this._waveIndex < waves.length && this._wavesClock >= (waves[this._waveIndex].start||0)){ const w=waves[this._waveIndex]; // schedule spawns
      if(!w._left){ w._left = w.count||1; w._timer=0; }
      w._timer -= dt; if(w._timer <= 0 && w._left>0){ const sx=this._evalSpawnCoord(w.spawn?.x, 'x'); const sy=this._evalSpawnCoord(w.spawn?.y, 'y'); const shootCfg = w.shoot ? { ...w.shoot } : null; const enemy = new Enemy(sx, sy, this.game.loader.image('enemy'), { state: w.ai?.state || 'chase', shoot: shootCfg }); this.objects.push(enemy); w._left--; w._timer = (w.spacing||0.5); if(w._left===0){ this._waveIndex++; } }
      else break;
    }
    // loop option
    if(this._waveIndex >= waves.length && (this._waves.loops||false)){ this._wavesClock=0; this._waveIndex=0; waves.forEach(w=>{ delete w._left; delete w._timer; }); }
  }

  _handlePause(){ const input=this.game.input; if(input.pressed('Escape')){ this.paused=!this.paused; this.pauseMenu.visible=this.paused; if(this.paused) this.game.sounds.play('pause',{volume:0.2}); } }

  _checkGameOver(){ if(this.lives<0 && !this.over){ this.over=true; this.gameOver.show(); } }

  update(dt){ if(!this.ready) return; this._handlePause(); if(this.paused){ this.game.input.postUpdate(); return; }
    const input=this.game.input; if(input.pressed('Digit1')) this.camera.setAxes(true,false); if(input.pressed('Digit2')) this.camera.setAxes(false,true); if(input.pressed('Digit3')) this.camera.setAxes(true,true); if(input.pressed('KeyC')) this.camera.deadzoneMode=this.camera.deadzoneMode==='ratio'?'px':'ratio'; if(input.pressed('KeyG')) this.camera.debugShowDeadzone=!this.camera.debugShowDeadzone; if(input.pressed('KeyO')){ if(this.camera.deadzoneMode==='ratio') this.camera.deadzone.w=Math.max(0.05,this.camera.deadzone.w-0.05); else this.camera.deadzonePx.w=Math.max(40,this.camera.deadzonePx.w-20); } if(input.pressed('KeyP')){ if(this.camera.deadzoneMode==='ratio') this.camera.deadzone.w=Math.min(0.9,this.camera.deadzone.w+0.05); else this.camera.deadzonePx.w=Math.min(this.game.canvas.width,this.camera.deadzonePx.w+20); } if(input.pressed('KeyK')){ if(this.camera.deadzoneMode==='ratio') this.camera.deadzone.h=Math.max(0.05,this.camera.deadzone.h-0.05); else this.camera.deadzonePx.h=Math.max(40,this.camera.deadzonePx.h-20); } if(input.pressed('KeyL')){ if(this.camera.deadzoneMode==='ratio') this.camera.deadzone.h=Math.min(0.9,this.camera.deadzone.h+0.05); else this.camera.deadzonePx.h=Math.min(this.game.canvas.height,this.camera.deadzonePx.h+20); }

    // Updates
    for(const o of this.objects){ if(!o.alive) continue; o.grounded=false; if(o._inv){ o._inv=Math.max(0,o._inv-dt);} o.update(dt,this); }

    // Collisions with tiles & polygons
    this.collision.staticSolids.length=0; for(const o of this.objects){ if(!o.alive||!o.collider) continue; const around=this.tilemap.querySolidsAround(o.getAABB(),1); for(const s of around) s.tag=s.tag||'tile'; this.collision.staticSolids.push(...around); }
    this.collision.staticSolids.push(...this._staticPolys);
    this.collision.update(this.objects.filter(o=>o.alive));

    // Handle deaths & scoring & particles
    const survivors=[]; for(const o of this.objects){ if(o.alive){ survivors.push(o); } else { if(o.tag==='projectile' && o._pooled){ this.projectilePool.release(o); } if(o.tag==='enemy'){ o.onDeath?.(this); this.game.sounds.play('explode',{volume:0.2}); } if(o.tag==='player'){ this.lives--; if(this.lives>=0){ o.alive=true; o.hp=3; o.pos.x=this.camera.pos.x+this.game.canvas.width/2-12; o.pos.y=this.camera.pos.y+80; survivors.push(o); this.game.sounds.play('respawn',{volume:0.2}); } } } }
    this.objects = survivors;

    // Multiplier decay
    this.multTimer-=dt; if(this.multTimer<=0) this.multiplier=Math.max(1.0, this.multiplier - this.multDecay*dt);

    // Camera / scroll
    if(this.cfg.scroll){ this._autoScroll(dt); } else { this.camera.update(dt); }

    // Waves JSON
    this._updateWaves(dt);

    // Particles
    this.particles.update(dt);

    // Bursts
    this._processBurst(dt);

    // End input
    if(this.over && this.game.input.pressed('Enter')){ // restart
      const opts={ mode:this.mode, tiledUrl:this._tiledUrl }; const next=new MainScene(this.game, opts); this.game.setScene(next); }
    this._checkGameOver();
    this.game.input.postUpdate();
  }

  render(ctx){ if(!this.ready) return; for(const layer of this.parallax) layer.render(ctx,this.camera,this.game.canvas.width,this.game.canvas.height); this.tilemap.render(ctx,this.camera); const vis=this.objects.slice().sort((a,b)=>a.z-b.z); for(const o of vis) o.render(ctx,this.camera); this.particles.render(ctx,this.camera); this.camera.renderDeadzoneOverlay(ctx); this.hud.render(ctx); this.pauseMenu.render(ctx); this.gameOver.render(ctx); }
}
