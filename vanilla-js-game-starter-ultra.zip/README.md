
# Vanilla JS Game Starter — ULTRA

Gabarit **vanilla JavaScript (ES Modules)** pour créer rapidement des jeux **2D** : plateformer, run’n’gun, shmup, top‑down.

## 🚀 Fonctionnalités principales

- Boucle de jeu `requestAnimationFrame` (update fixe + render)
- Gestion **clavier/souris**
- **Sprite/Animation**, **Parallax**, **Caméra** avec **deadzone** (ratio/pixels)
- **Collisions**: AABB, Cercle, **Polygon (SAT)** + grille spatiale (broadphase)
- **TileMap** (rendu + collisions) + **Tiled JSON** (orthogonal, CSV)
- **Entités**: Player, Enemy (IA FSM configurable), Pickup, Projectile (pool)
- **Tirs**: primaire, rafales, **patterns ennemis** (cône, spirale)
- **Waves JSON** (définition data de vagues) + **éditeur** web minimal
- **Auto‑scroll**: shmup vertical, **top‑down horizontal/diagonal**
- **Particules** (pool) + explosions
- **HUD complet** (score, vies), **Pause (Échap)**, **Game Over** (score final, multiplier)
- **Sons réels** (WAV locaux) via `SoundManager.queue()` + `loadAll()`

## 🧭 Démarrer

```bash
npx http-server
# ou
python -m http.server
```

Ouvrir `index.html`. Choisir un mode par URL, ex. :
- `?mode=platformer`
- `?mode=runngun`
- `?mode=shmup`
- `?mode=topdown` (libre), `?mode=topdown_h` (auto-scroll horizontal), `?mode=topdown_d` (auto-scroll diagonal)

## 🎮 Contrôles

- Déplacements: Flèches / ZQSD (WASD)  
- Saut: **Espace** (variable) + **coyote time**  
- Tir primaire: **F** ou **clic gauche**  
- Rafales (secondaire): **R** ou **clic droit**  
- Pause: **Échap**  
- Caméra: `C` (mode deadzone) · `O/P` (largeur) · `K/L` (hauteur) · `G` (overlay)

## 🗺️ Niveaux & Waves

- `assets/level1.json`: niveau Tiled plateformer (tiles solides via propriété `solid=true`)
- `assets/level_shmup.json`: niveau vertical pour shmup
- `assets/waves.json`: définition des vagues shmup/top‑down (voir schéma ci‑dessous)
- Éditeur simple: `tools/waves_editor.html`

### Schéma `assets/waves.json`

```json
{
  "loops": true,
  "waves": [
    {
      "start": 1.0,
      "count": 5,
      "spacing": 0.6,
      "spawn": { "x": "range(60,740)", "y": "top" },
      "ai": { "state": "chase" },
      "shoot": { "pattern": "cone", "count": 5, "spreadDeg": 45, "speed": 240, "interval": 1.2 }
    }
  ]
}
```

- `start`: seconde de début de la vague
- `count`: nombre d’ennemis (répétitions)
- `spacing`: délai entre spawns d’une même vague
- `spawn.x`/`spawn.y`: position (nombre) ou mot‑clé `top|bottom|left|right|center` ou `range(min,max)`
- `ai.state`: état initial (ex. `patrol`, `chase`, `attack`)
- `shoot.pattern`: `none|cone|spiral` (+ paramètres `count`, `spreadDeg`, `speed`, `interval`)

## 🔊 Sons

Des WAVs **locaux** sont fournis dans `assets/sounds/` (générés). Ajoutez les vôtres via :

```js
sounds.queue('laser', 'assets/sounds/laser.wav');
await sounds.loadAll();
sounds.play('laser');
```

## 🧩 Collisions (SAT)

- Ajoutez des **pentes** ou obstacles via un `objectgroup` Tiled avec des **polygones**.  
- Le chargeur transforme ces objets en colliders **polygon** statiques (testés via **SAT**).

## 🛠️ Personnalisation rapide

- Changer de mode par défaut dans `main.js`
- Modifier l’auto‑scroll dans `game/MainScene.js` (`MODE_CONFIG`)  
- Ajuster la difficulté : dégâts ennemis, cadence de tir, points, **multiplicateur** (incrément/décroissance)

Bon dev ! ✨
