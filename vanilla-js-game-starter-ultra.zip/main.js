import { Game } from './engine/core/Game.js';
import { AssetLoader } from './engine/assets/AssetLoader.js';
import { SoundManager } from './engine/audio/SoundManager.js';
import { InputManager } from './engine/input/InputManager.js';
import { MainScene } from './game/MainScene.js';

const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d', { alpha: false });

function makeCanvas(w,h,draw){ const c=document.createElement('canvas'); c.width=w; c.height=h; const g=c.getContext('2d'); draw(g,w,h); return c.toDataURL(); }
function spritePlayer(){ return makeCanvas(72,72,(g,w,h)=>{ g.imageSmoothingEnabled=false; for(let i=0;i<9;i++){ const x=(i%3)*24, y=((i/3)|0)*24; g.fillStyle='#2ecc71'; g.fillRect(x+2,y+4,20,18); g.fillStyle='#27ae60'; g.fillRect(x+4,y+6,16,10); g.fillStyle='#fff'; g.fillRect(x+7,y+10,3,3); g.fillRect(x+14,y+10,3,3); g.fillStyle='#000'; g.fillRect(x+8,y+11,1,1); g.fillRect(x+15,y+11,1,1); if(i>=3&&i<=7){ g.fillStyle='#1e8449'; const t=i-3; const off=(t%2===0)?2:-2; g.fillRect(x+6,y+18,4,4); g.fillRect(x+14,y+18+off,4,4);} } }); }
function spriteEnemy(){ return makeCanvas(72,24,(g,w,h)=>{ for(let i=0;i<3;i++){ const x=i*24; g.fillStyle='#e74c3c'; g.fillRect(x+2,2,20,20); g.fillStyle='#c0392b'; g.fillRect(x+4,6,16,12); g.fillStyle='#fff'; g.fillRect(x+7,10,3,3); g.fillRect(x+14,10,3,3); g.fillStyle='#000'; g.fillRect(x+8,11,1,1); g.fillRect(x+15,11,1,1);} }); }
function spritePickup(){ return makeCanvas(96,16,(g,w,h)=>{ for(let i=0;i<6;i++){ const x=i*16; g.fillStyle='#f1c40f'; g.fillRect(x+2,2,12,12); g.fillStyle='#f39c12'; g.fillRect(x+4,4,8,8);} }); }
function tileset(){ return makeCanvas(64,32,(g,w,h)=>{ g.fillStyle='#2ecc71'; g.fillRect(0,0,32,8); g.fillStyle='#27ae60'; g.fillRect(0,8,32,24); g.fillStyle='#95a5a6'; g.fillRect(32,0,32,32); g.fillStyle='#7f8c8d'; for(let y=4;y<32;y+=8) for(let x=36;x<64;x+=8) g.fillRect(x,y,4,4); }); }
function parallaxFar(){ return makeCanvas(256,144,(g,w,h)=>{ g.fillStyle='#0b132b'; g.fillRect(0,0,w,h); g.fillStyle='#1c2541'; g.fillRect(0,h-40,w,40); g.fillStyle='#3a506b'; for(let i=0;i<20;i++){ const x=Math.random()*w, y=h-40-Math.random()*30, mw=20+Math.random()*40, mh=10+Math.random()*20; g.fillRect(x|0,y|0,mw|0,mh|0);} }); }
function parallaxMid(){ return makeCanvas(256,144,(g,w,h)=>{ g.clearRect(0,0,w,h); g.fillStyle='#5bc0be'; for(let i=0;i<30;i++){ const x=Math.random()*w, y=h-30-Math.random()*40, mw=10+Math.random()*30, mh=6+Math.random()*16; g.fillRect(x|0,y|0,mw|0,mh|0);} }); }
function parallaxNear(){ return makeCanvas(256,144,(g,w,h)=>{ g.clearRect(0,0,w,h); g.fillStyle='#e0fbfc'; for(let i=0;i<50;i++){ const x=Math.random()*w, y=h-20-Math.random()*30, mw=4+Math.random()*12, mh=4+Math.random()*10; g.fillRect(x|0,y|0,mw|0,mh|0);} }); }

const loader = new AssetLoader();
const sounds = new SoundManager();
const input = new InputManager(canvas);
const game = new Game(canvas, ctx, loader, sounds, input);

loader.queueImage('player', spritePlayer());
loader.queueImage('enemy', spriteEnemy());
loader.queueImage('pickup', spritePickup());
loader.queueImage('tiles', tileset());
loader.queueImage('bg1', parallaxFar());
loader.queueImage('bg2', parallaxMid());
loader.queueImage('bg3', parallaxNear());

// Sounds: real WAVs
const SND = (n)=>`assets/sounds/${n}.wav`;
['jump','coin','shoot','burst','explode','enemy_shoot','respawn','pause'].forEach(k=>sounds.queue(k, SND(k)));
await sounds.loadAll().catch(()=>{});

const MODE = new URLSearchParams(location.search).get('mode') || 'platformer';
document.getElementById('modeLabel').textContent = MODE;

(async function init(){ await loader.loadAll(); const tiledUrl = (MODE==='shmup') ? 'assets/level_shmup.json' : 'assets/level1.json'; const scene = new MainScene(game, { mode: MODE, tiledUrl }); game.setScene(scene); game.start(); })();
