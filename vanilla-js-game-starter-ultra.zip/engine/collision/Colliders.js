
import { Rect } from '../math/Rect.js';
import { Vector2 } from '../math/Vector2.js';

export class Collider { constructor(type){ this.type=type; this.isTrigger=false; this.offset=new Vector2(0,0);} attach(owner){ this.owner=owner; return this; } }
export class AABBCollider extends Collider { constructor(w,h){ super('aabb'); this.w=w; this.h=h; } rect(){ const x=(this.owner?.pos.x||0)+this.offset.x; const y=(this.owner?.pos.y||0)+this.offset.y; return new Rect(x,y,this.w,this.h);} getAABB(){ const r=this.rect(); return {x:r.x,y:r.y,w:r.w,h:r.h}; } }
export class CircleCollider extends Collider { constructor(r){ super('circle'); this.r=r; } center(){ const x=(this.owner?.pos.x||0)+this.offset.x; const y=(this.owner?.pos.y||0)+this.offset.y; return new Vector2(x+this.r,y+this.r);} getAABB(){ const c=this.center(); return { x:c.x-this.r, y:c.y-this.r, w:this.r*2, h:this.r*2 }; } }
export class PolygonCollider extends Collider { constructor(points){ super('polygon'); this.points = points; } worldPoints(){ const ox=(this.owner?.pos.x||0)+this.offset.x; const oy=(this.owner?.pos.y||0)+this.offset.y; return this.points.map(p=>({ x: ox + p.x, y: oy + p.y })); } getAABB(){ const pts=this.worldPoints(); let minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity; for(const p of pts){ if(p.x<minX)minX=p.x; if(p.y<minY)minY=p.y; if(p.x>maxX)maxX=p.x; if(p.y>maxY)maxY=p.y; } return { x:minX, y:minY, w:maxX-minX, h:maxY-minY }; } }

function projectAxis(points, axis){ let min=Infinity, max=-Infinity; for(const p of points){ const proj = (p.x*axis.x + p.y*axis.y); if(proj<min)min=proj; if(proj>max)max=proj; } return {min,max}; }
function overlap1D(a,b){ return !(a.max < b.min || b.max < a.min); }
function getOverlap(a,b){ return Math.min(a.max - b.min, b.max - a.min); }

function polygonNormals(points){ const norms=[]; for(let i=0;i<points.length;i++){ const p1=points[i], p2=points[(i+1)%points.length]; const edge={ x:p2.x-p1.x, y:p2.y-p1.y }; const n={ x:-edge.y, y:edge.x }; const len=Math.hypot(n.x,n.y)||1; norms.push({ x:n.x/len, y:n.y/len }); } return norms; }

function rectToPoly(rect){ const {x,y,w,h}=rect; return [ {x:x,y:y}, {x:x+w,y:y}, {x:x+w,y:y+h}, {x:x,y:y+h} ]; }

export const Collisions = {
  aabbVsAabb(a,b){ const ra=a.rect(), rb=b.rect(); if(!(ra.right>rb.left && ra.left<rb.right && ra.bottom>rb.top && ra.top<rb.bottom)) return null; const dx1=rb.right-ra.left, dx2=ra.right-rb.left, dy1=rb.bottom-ra.top, dy2=ra.bottom-rb.top; const penX=Math.min(dx1,dx2), penY=Math.min(dy1,dy2); if(penX<penY){ const nx=(dx1<dx2)?-1:1; return { normal:new Vector2(nx,0), penetration:penX }; } else { const ny=(dy1<dy2)?-1:1; return { normal:new Vector2(0,ny), penetration:penY }; } },
  circleVsCircle(a,b){ const ca=a.center(), cb=b.center(); const d=Vector2.sub(cb,ca); const dist=d.length(); const pen=(a.r+b.r)-dist; if(pen<=0) return null; const normal=dist===0?new Vector2(1,0):d.scale(1/dist); return { normal, penetration:pen }; },
  aabbVsCircle(aabb,circ){ const r=aabb.rect(); const c=circ.center(); const nx=Math.max(r.left,Math.min(c.x,r.right)); const ny=Math.max(r.top,Math.min(c.y,r.bottom)); const dx=c.x-nx, dy=c.y-ny; const d2=dx*dx+dy*dy; if(d2>circ.r*circ.r) return null; const d=Math.sqrt(d2); const n=d===0?new Vector2(1,0):new Vector2(dx/d,dy/d); const pen=circ.r-d; return { normal:n, penetration:pen }; },
  polygonVsPolygon(pa, pb){ const A=pa.worldPoints(), B=pb.worldPoints(); const axes=[...polygonNormals(A), ...polygonNormals(B)]; let minPen=Infinity; let bestAxis=null;
    for(const axis of axes){ const pA=projectAxis(A,axis), pB=projectAxis(B,axis); if(!overlap1D(pA,pB)) return null; const pen=getOverlap(pA,pB); if(pen<minPen){ minPen=pen; bestAxis=axis; } }
    // Direction from A to B to orient normal
    const centerA=A.reduce((acc,p)=>({x:acc.x+p.x,y:acc.y+p.y}),{x:0,y:0}); centerA.x/=A.length; centerA.y/=A.length;
    const centerB=B.reduce((acc,p)=>({x:acc.x+p.x,y:acc.y+p.y}),{x:0,y:0}); centerB.x/=B.length; centerB.y/=B.length;
    const ab={ x:centerB.x-centerA.x, y:centerB.y-centerA.y }; const dp=ab.x*bestAxis.x + ab.y*bestAxis.y; const normal = dp<0 ? new Vector2(-bestAxis.x,-bestAxis.y) : new Vector2(bestAxis.x,bestAxis.y);
    return { normal, penetration: minPen };
  },
  aabbVsPolygon(aabb, poly){ const rectPoly = rectToPoly(aabb.rect()); const pa = { worldPoints: ()=>rectPoly }; return this.polygonVsPolygon(pa, poly); },
  polygonVsAabb(poly, aabb){ const res = this.aabbVsPolygon(aabb, poly); if(!res) return null; res.normal.x*=-1; res.normal.y*=-1; return res; }
};
