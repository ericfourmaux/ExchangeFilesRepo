
import { Collisions } from './Colliders.js';
export class SpatialHash { constructor(cellSize=64){ this.cellSize=cellSize; this.map=new Map(); } _key(cx,cy){ return `${cx},${cy}`; } clear(){ this.map.clear(); } insert(obj){ const b=obj.getAABB?.(); if(!b) return; const cs=this.cellSize; const minCX=Math.floor(b.x/cs), minCY=Math.floor(b.y/cs); const maxCX=Math.floor((b.x+b.w)/cs), maxCY=Math.floor((b.y+b.h)/cs); obj._cells=[]; for(let cy=minCY; cy<=maxCY; cy++){ for(let cx=minCX; cx<=maxCX; cx++){ const k=this._key(cx,cy); if(!this.map.has(k)) this.map.set(k,new Set()); this.map.get(k).add(obj); obj._cells.push(k);} } } query(b){ const res=new Set(); if(!b) return []; const cs=this.cellSize; const minCX=Math.floor(b.x/cs), minCY=Math.floor(b.y/cs); const maxCX=Math.floor((b.x+b.w)/cs), maxCY=Math.floor((b.y+b.h)/cs); for(let cy=minCY; cy<=maxCY; cy++){ for(let cx=minCX; cx<=maxCX; cx++){ const k=this._key(cx,cy); const bucket=this.map.get(k); if(bucket) bucket.forEach(o=>res.add(o)); } } return Array.from(res);} }
export class CollisionSystem { constructor(cellSize=64){ this.spatial=new SpatialHash(cellSize); this.staticSolids=[]; }
  update(objects){ this.spatial.clear(); for(const o of objects){ if(o?.collider) this.spatial.insert(o);} for(const a of objects){ if(!a?.collider) continue; const cands=this.spatial.query(a.getAABB()); for(const b of cands){ if(a===b||!b?.collider) continue; const aId=a._id??0, bId=b._id??0; if(aId&&bId&&aId>bId) continue; const res=this._testPair(a,b); if(res) this._resolve(a,b,res,false);} }
    if(this.staticSolids.length>0){ for(const o of objects){ if(!o?.collider) continue; for(const s of this.staticSolids){ if(!s?.collider||!s.getAABB) continue; const r=this._testPair(o,s); if(r) this._resolve(o,s,r,true);} } }
  }
  _testPair(a,b){ const ca=a.collider, cb=b.collider; if(!ca||!cb) return null; const t=`${ca.type}-${cb.type}`; switch(t){
      case 'aabb-aabb': return Collisions.aabbVsAabb(ca,cb);
      case 'circle-circle': return Collisions.circleVsCircle(ca,cb);
      case 'aabb-circle': return Collisions.aabbVsCircle(ca,cb);
      case 'circle-aabb': { const r=Collisions.aabbVsCircle(cb,ca); if(!r) return null; r.normal.x*=-1; r.normal.y*=-1; return r; }
      case 'polygon-polygon': return Collisions.polygonVsPolygon(ca,cb);
      case 'aabb-polygon': return Collisions.aabbVsPolygon(ca,cb);
      case 'polygon-aabb': return Collisions.polygonVsAabb(ca,cb);
      default: return null;
    } }
  _resolve(a,b,res,bStatic=false){ const ca=a.collider, cb=b.collider; if(ca.isTrigger||cb.isTrigger){ a.onTrigger?.(b); b.onTrigger?.(a); return; } const nx=res.normal.x, ny=res.normal.y, pen=res.penetration; if(bStatic){ a.pos.x-=nx*pen; a.pos.y-=ny*pen; } else { a.pos.x-=nx*(pen*0.5); a.pos.y-=ny*(pen*0.5); b.pos.x+=nx*(pen*0.5); b.pos.y+=ny*(pen*0.5); } const avx=a.vel?.x??0, avy=a.vel?.y??0; const bvx=(bStatic?0:(b.vel?.x??0)), bvy=(bStatic?0:(b.vel?.y??0)); const rvx=avx-bvx, rvy=avy-bvy; const vn=rvx*nx+rvy*ny; if(vn<0){ if(a.vel){ const k=bStatic?1.0:0.5; a.vel.x-=vn*nx*k; a.vel.y-=vn*ny*k; } if(!bStatic && b.vel){ b.vel.x+=vn*nx*0.5; b.vel.y+=vn*ny*0.5; } } a.onCollision?.(b,res); b.onCollision?.(a,{ normal:{x:-nx,y:-ny}, penetration:pen }); }
}
