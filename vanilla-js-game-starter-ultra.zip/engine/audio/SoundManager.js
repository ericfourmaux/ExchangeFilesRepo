
export class SoundManager {
  constructor(){ this._defs=new Map(); this._buffers=new Map(); this._ctx=null; }
  queue(key, src){ this._defs.set(key, src); }
  async loadAll(){
    // Use HTMLAudio fallback if WebAudio not allowed by autoplay policies; but try decode for precise control
    this._ctx = this._ctx || new (window.AudioContext||window.webkitAudioContext)();
    for(const [key,src] of this._defs){
      const resp = await fetch(src); const arr = await resp.arrayBuffer();
      const buf = await this._ctx.decodeAudioData(arr.slice(0));
      this._buffers.set(key, buf);
    }
  }
  play(key,{volume=0.9, loop=false, rate=1.0}={}){
    if(!this._ctx) this._ctx = new (window.AudioContext||window.webkitAudioContext)();
    const buf=this._buffers.get(key); if(!buf){ const a=new Audio(this._defs.get(key)); a.volume=volume; a.loop=loop; a.play().catch(()=>{}); return a; }
    const src=this._ctx.createBufferSource(); src.buffer=buf; src.playbackRate.value = rate; const gain=this._ctx.createGain(); gain.gain.value=volume; src.connect(gain).connect(this._ctx.destination); src.loop=loop; src.start(); return { stop: ()=>src.stop() };
  }
  async beep({frequency=440,duration=0.12,type='square',volume=0.2}={}){
    if(!this._ctx) this._ctx=new (window.AudioContext||window.webkitAudioContext)();
    const ctx=this._ctx; const osc=ctx.createOscillator(); const gain=ctx.createGain(); osc.type=type; osc.frequency.value=frequency; gain.gain.value=volume; osc.connect(gain).connect(ctx.destination); osc.start(); await new Promise(r=>setTimeout(r,duration*1000)); osc.stop();
  }
}
