
import { TileMap } from '../world/TileMap.js';

export class TiledLoader {
  constructor(loader){ this.loader=loader; }
  async loadFromURL(url){ const r=await fetch(url); if(!r.ok) throw new Error('Tiled JSON introuvable: '+url); const j=await r.json(); return this._buildFromJSON(j); }
  async loadFromObject(json){ return this._buildFromJSON(json); }
  async _buildFromJSON(json){
    if(json.orientation!=='orthogonal') throw new Error('Seul le mode orthogonal est supporté.');
    const tileW=json.tilewidth, tileH=json.tileheight; const ts0=json.tilesets[0]; const firstGid=ts0.firstgid||1; const key='tiles';
    if(!this.loader.image(key)){ if(ts0.image){ await this.loader.loadImage(key, ts0.image);} else { throw new Error('Tileset image introuvable et clé "tiles" absente.'); } }
    const solid=new Set(); if(Array.isArray(ts0.tiles)){ for(const t of ts0.tiles){ const props=(t.properties||[]).reduce((a,p)=>(a[p.name]=p.value,a),{}); if(props.solid) solid.add(firstGid+t.id); } }
    const tl=json.layers.find(l=>l.type==='tilelayer'); if(!tl) throw new Error('Aucune tilelayer.'); const W=tl.width, H=tl.height; const data=tl.data; if(typeof data==='string') throw new Error('Encodage non géré (CSV/array attendu).');
    const tiles2D=[]; for(let y=0;y<H;y++){ tiles2D[y]=[]; for(let x=0;x<W;x++){ const gid=data[y*W+x]||0; tiles2D[y][x]=gid===0?-1:gid; } }
    const tilemap=new TileMap(tiles2D,tileW,this.loader.image(key),solid);

    const spawns={ player:null, enemies:[], pickups:[], polygons:[] };
    for(const layer of json.layers){ if(layer.type==='objectgroup'){
      for(const o of layer.objects){ const type=(o.type||o.name||'').toLowerCase(); const ox=Math.round(o.x), oy=Math.round(o.y - tileH);
        if(type==='player' && !spawns.player) spawns.player={x:ox,y:oy};
        else if(type==='enemy') spawns.enemies.push({x:ox,y:oy});
        else if(type==='pickup') spawns.pickups.push({x:ox,y:oy});
        else if(o.polygon){ // slope/obstacle polygon
          spawns.polygons.push({ x: Math.round(o.x), y: Math.round(o.y), points: o.polygon.map(p=>({x:p.x, y:p.y})) });
        }
      }
    } }
    return { tilemap, spawns };
  }
}
