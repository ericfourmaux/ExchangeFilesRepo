
import { Pool } from '../utils/Pool.js';
import { Particle } from './Particle.js';

export class ParticleSystem { constructor(){ this.pool=new Pool(()=>new Particle()); this.items=[]; }
  explosion(x,y,{color='#ffdd66', count=24, speed=180, spread=2*Math.PI}={}){ for(let i=0;i<count;i++){ const a=Math.random()*spread; const s=speed*(0.4+0.6*Math.random()); const px=this.pool.acquire(); px.reset(x,y,Math.cos(a)*s,Math.sin(a)*s,0.5+Math.random()*0.6,color,2+Math.random()*2); this.items.push(px); } }
  update(dt){ for(const p of this.items){ if(p.alive) p.update(dt); } this.items=this.items.filter(p=>p.alive); }
  render(ctx,camera){ for(const p of this.items) p.render(ctx,camera); }
}
