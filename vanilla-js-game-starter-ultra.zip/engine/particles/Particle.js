
export class Particle { constructor(){ this.alive=false; this.x=0; this.y=0; this.vx=0; this.vy=0; this.life=0; this.color='#fff'; this.size=2; }
  reset(x,y,vx,vy,life,color,size){ this.x=x; this.y=y; this.vx=vx; this.vy=vy; this.life=life; this.color=color; this.size=size; this.alive=true; }
  update(dt){ if(!this.alive) return; this.x+=this.vx*dt; this.y+=this.vy*dt; this.vx*=0.98; this.vy+=30*dt; this.life-=dt; if(this.life<=0) this.alive=false; }
  render(ctx,camera){ if(!this.alive) return; const p=camera.worldToScreen(this.x,this.y); ctx.fillStyle=this.color; ctx.fillRect((p.x|0),(p.y|0),this.size,this.size); }
}
